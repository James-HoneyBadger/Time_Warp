#!/usr/bin/env python3
"""Simple graphics test that shows a window and waits"""

from core.interpreter import Time_WarpInterpreter
import time

def simple_graphics_test():
    interp = Time_WarpInterpreter()
    
    print("Creating graphics window...")
    
    # Initialize graphics
    interp.execute_line("GAMESCREEN 600, 400")
    print("Screen created")
    
    # Dark blue background
    interp.execute_line("GAMEBG 0, 0, 100")
    print("Background set")
    
    # Draw some colorful shapes
    interp.execute_line("GAMECOLOR 255, 0, 0")
    interp.execute_line("GAMERECT 50, 50, 100, 80")
    print("Red rectangle drawn")
    
    interp.execute_line("GAMECOLOR 0, 255, 0") 
    interp.execute_line("GAMECIRCLE 300, 200, 60")
    print("Green circle drawn")
    
    interp.execute_line("GAMECOLOR 255, 255, 0")
    interp.execute_line("GAMETEXT 200, 300, \"Time_Warp GRAPHICS TEST\"")
    print("Yellow text drawn")
    
    # Update display
    interp.execute_line("GAMEUPDATE")
    print("Display updated")
    
    print("Graphics window should be visible. Waiting 10 seconds...")
    time.sleep(10)
    print("Test complete")

if __name__ == "__main__":
    simple_graphics_test()