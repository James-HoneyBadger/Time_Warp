#!/usr/bin/env python3
"""
Time_Warp III Refactoring Demo
Demonstrates the new architecture and capabilities
"""

import sys
import os

# Add project root to path
project_root = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, project_root)

def demo_error_system():
    """Demonstrate the error management system"""
    print("🔧 Error Management System Demo")
    print("-" * 40)
    
    from core.language.errors.error_manager import ErrorManager, ErrorCode, SourceLocation
    
    # Create error manager
    manager = ErrorManager()
    
    # Add some errors
    location = SourceLocation(15, 8, "example.james")
    manager.add_error(
        ErrorCode.UNDEFINED_VARIABLE,
        "Variable 'counter' is not defined",
        location,
        suggestions=["Define 'counter' before using it", "Check variable name spelling"]
    )
    
    manager.add_warning(
        ErrorCode.UNEXPECTED_TOKEN,
        "Unused variable 'temp'",
        SourceLocation(22, 4, "example.james")
    )
    
    # Display errors
    print("Errors found:")
    print(manager.format_errors())
    print("\\nWarnings:")
    print(manager.format_warnings())
    
    print(f"\\nTotal errors: {len(manager.errors)}")
    print(f"Total warnings: {len(manager.warnings)}")

def demo_stdlib():
    """Demonstrate the standard library"""
    print("\\n📚 Standard Library Demo")
    print("-" * 40)
    
    from core.language.stdlib.core import StandardLibrary
    
    stdlib = StandardLibrary()
    
    # Show available functions
    functions = list(stdlib.functions.keys())
    print(f"Available functions ({len(functions)}): {', '.join(functions[:10])}...")
    
    # Demonstrate some functions
    try:
        print(f"\\nMath functions:")
        print(f"  ABS(-5) = {stdlib.functions['ABS'](-5)}")
        print(f"  SQRT(16) = {stdlib.functions['SQRT'](16)}")
        print(f"  MAX(3, 7, 1) = {stdlib.functions['MAX'](3, 7, 1)}")
        
        print(f"\\nString functions:")
        print(f"  LEN('hello') = {stdlib.functions['LEN']('hello')}")
        print(f"  UPPER$('hello') = {stdlib.functions['UPPER$']('hello')}")
        
        print(f"\\nConstants:")
        print(f"  PI = {stdlib.get_constant('PI'):.6f}")
        print(f"  E = {stdlib.get_constant('E'):.6f}")
        
    except Exception as e:
        print(f"Error in stdlib demo: {e}")

def demo_runtime():
    """Demonstrate the runtime engine"""
    print("\\n⚙️ Runtime Engine Demo")
    print("-" * 40)
    
    from core.language.runtime.engine import RuntimeEngine, ExecutionMode
    
    runtime = RuntimeEngine()
    
    # Show execution modes
    print(f"Available modes: {[mode.value for mode in ExecutionMode]}")
    print(f"Current mode: {runtime.context.mode.value}")
    
    # Variable management
    runtime.set_variable("x", 10)
    runtime.set_variable("name", "Time_Warp III")
    runtime.set_variable("pi_approx", 3.14159)
    
    print(f"\\nVariables:")
    variables = runtime.context.variables.list_variables()
    for name, var in variables.items():
        print(f"  {name} = {var.value} ({var.type_hint})")
    
    # Function calls
    print(f"\\nFunction calls:")
    try:
        result = runtime.call_function("ABS", -42)
        print(f"  ABS(-42) = {result}")
        
        result = runtime.call_function("LEN", "Hello World")
        print(f"  LEN('Hello World') = {result}")
        
    except Exception as e:
        print(f"  Error calling function: {e}")

def demo_plugins():
    """Demonstrate the plugin system"""
    print("\\n🔌 Plugin System Demo")
    print("-" * 40)
    
    from core.language.plugins.manager import PluginManager
    
    plugin_manager = PluginManager()
    
    # Show loaded plugins
    plugins = plugin_manager.list_plugins()
    print(f"Loaded plugins ({len(plugins)}):")
    for plugin in plugins:
        status = "✅ enabled" if plugin['enabled'] else "❌ disabled"
        print(f"  • {plugin['name']} v{plugin['version']} ({status})")
        print(f"    {plugin['description']}")
    
    # Enable all plugins
    print(f"\\nEnabling all plugins...")
    results = plugin_manager.enable_all_plugins()
    enabled_count = sum(1 for success in results.values() if success)
    print(f"Successfully enabled {enabled_count}/{len(results)} plugins")
    
    # Show statistics
    stats = plugin_manager.get_statistics()
    print(f"\\nPlugin statistics:")
    print(f"  Total plugins: {stats['registry']['total_plugins']}")
    print(f"  Enabled plugins: {stats['registry']['enabled_plugins']}")
    print(f"  Runtime hooks: {stats['runtime_hooks']}")

def demo_lexer():
    """Demonstrate the enhanced lexer"""
    print("\\n📝 Enhanced Lexer Demo")
    print("-" * 40)
    
    from core.language.compiler.lexer import EnhancedLexer
    
    lexer = EnhancedLexer()
    
    # Test program
    code = '''
    x = 5 + 3 * 2
    name$ = "Hello, World!"
    IF x > 10 THEN
        PRINT name$
    ENDIF
    '''
    
    print(f"Tokenizing code:")
    print(code)
    
    tokens = lexer.tokenize(code.strip(), "demo.james")
    
    print(f"\\nTokens ({len(tokens)}):")
    for i, token in enumerate(tokens[:15]):  # Show first 15 tokens
        print(f"  {i+1:2d}. {token.type.name:12} | {token.value!r:15} | Line {token.location.line}")
    
    if len(tokens) > 15:
        print(f"  ... and {len(tokens) - 15} more tokens")
    
    # Check for errors
    errors = lexer.get_errors()
    if errors:
        print(f"\\nLexer errors: {len(errors)}")
        for error in errors:
            print(f"  {error}")
    else:
        print("\\n✅ No lexer errors")

def main():
    """Run all demos"""
    print("🚀 Time_Warp III Refactoring Demo")
    print("=" * 50)
    print("Showcasing the new modular architecture and enhanced capabilities")
    
    try:
        demo_error_system()
        demo_stdlib()
        demo_runtime()
        demo_plugins()
        demo_lexer()
        
        print("\\n" + "=" * 50)
        print("🎉 Demo completed successfully!")
        print("\\nThe Time_Warp III refactoring provides:")
        print("  • Robust error handling with helpful suggestions")
        print("  • Rich standard library with 40+ functions")  
        print("  • Flexible runtime supporting multiple execution modes")
        print("  • Extensible plugin system for customization")
        print("  • Enhanced compiler with better tokenization")
        print("  • Clean, maintainable modular architecture")
        
    except Exception as e:
        print(f"\\n❌ Demo error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()