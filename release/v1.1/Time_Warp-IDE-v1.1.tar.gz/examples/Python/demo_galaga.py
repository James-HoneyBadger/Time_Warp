#!/usr/bin/env python3
"""
Galaga Game Demo for Time_Warp
"""

import sys
import os

# Add project root to path
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

def demo_galaga_game():
    """Demonstrate the Galaga game running in Time_Warp"""
    
    print("🚀 GALAGA SPACE SHOOTER DEMO")
    print("=" * 50)
    print()
    
    # Show the game code structure
    print("📝 Game Features:")
    print("  • Text-based Galaga-style space shooter")
    print("  • Player movement (A/D keys)")
    print("  • Shooting mechanics (S key)")
    print("  • Enemy AI with random movement")
    print("  • Score system and multiple levels")
    print("  • Lives system")
    print("  • Collision detection")
    print()
    
    print("🎮 Game Layout:")
    print("  Row 1: [Empty space]")
    print("  Row 2: E E E E  (Enemies)")
    print("  Row 3: [Battle zone with bullets |]")
    print("  Row 4:     A    (Player)")
    print()
    
    print("🕹️  Controls:")
    print("  A - Move player left") 
    print("  D - Move player right")
    print("  S - Shoot bullet")
    print("  Q - Quit game")
    print()
    
    # Show game code preview
    print("💻 Time_Warp BASIC Code Preview:")
    print("=" * 30)
    
    game_preview = '''
10 PRINT "GALAGA SPACE SHOOTER"
20 LET PLAYER_POS = 5
30 LET SCORE = 0
40 LET LIVES = 3

REM Main game loop
250 PRINT "Level " + STR$(LEVEL)
270 PRINT "-----"

REM Draw enemies
320 FOR I = 1 TO 10
330 LET CHAR$ = " "
340 IF I = ENEMY1 AND ENEMY1_ALIVE = 1 THEN LET CHAR$ = "E"
350 IF I = ENEMY2 AND ENEMY2_ALIVE = 1 THEN LET CHAR$ = "E"
...

REM Process player input
650 IF CMD$ = "A" THEN GOSUB 1000  REM Move left
660 IF CMD$ = "D" THEN GOSUB 1100  REM Move right
670 IF CMD$ = "S" THEN GOSUB 1200  REM Shoot
...

1400 REM Check collisions
1410 IF BULLET_ACTIVE = 0 THEN RETURN
1420 IF BULLET_ROW <> 2 THEN RETURN
1430 IF BULLET_POS = ENEMY1 AND ENEMY1_ALIVE = 1 THEN GOSUB 1450
...

1450 REM Hit enemy
1451 LET ENEMY1_ALIVE = 0
1452 LET SCORE = SCORE + 100
1453 PRINT "ENEMY DESTROYED! +100 points"
'''
    
    print(game_preview)
    print("=" * 30)
    print()
    
    # Simulate a short gameplay sequence
    print("🎯 Simulated Gameplay:")
    print("-" * 20)
    
    gameplay_demo = [
        ("Level 1", "-----"),
        ("", "          "),
        ("Enemies:", "E E E E   "),
        ("Battle:", "          "),
        ("Player:", "     A    "),
        ("", "----------"),
        ("", "Score: 0  Lives: 3"),
        ("", ""),
        ("Command: S (Shoot)", "BANG!"),
        ("", "          "),
        ("Bullet hits:", "E | E E   "),
        ("", "          "),
        ("Player:", "     A    "),
        ("", "ENEMY DESTROYED! +100 points"),
        ("", "Score: 100  Lives: 3"),
    ]
    
    for description, display in gameplay_demo:
        if description:
            print(f"{description:<15} {display}")
        else:
            print(display)
    
    print()
    print("🏆 Game Progression:")
    print("  • Destroy all 4 enemies to advance to next level")
    print("  • Each level increases difficulty") 
    print("  • Bonus points awarded for level completion")
    print("  • Game ends when all lives are lost")
    print()
    
    print("📂 Files Created:")
    print("  • galaga_game.james - Full-featured version with graphics")
    print("  • galaga_simple.james - Intermediate text version")
    print("  • galaga_basic.james - Compatible Time_Warp BASIC version")
    print()
    
    print("🚀 To Play:")
    print("  1. Load Time_Warp IDE")
    print("  2. Open 'galaga_basic.time_warp'")
    print("  3. Run in BASIC mode")
    print("  4. Follow on-screen instructions")
    print()
    
    print("✨ Technical Features:")
    print("  • Pure Time_Warp BASIC implementation")
    print("  • No external dependencies")
    print("  • Compatible with current Time_Warp architecture")
    print("  • Uses standard BASIC commands (LET, IF, FOR, GOSUB)")
    print("  • Implements game loops and state management")
    print("  • Text-based graphics using character positioning")
    print()
    
    return True

if __name__ == "__main__":
    print("Starting Galaga Game Demo...")
    print()
    
    try:
        demo_galaga_game()
        print("🎮 Demo completed successfully!")
        print("\nThe Galaga-style space shooter game is ready to play in Time_Warp!")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)