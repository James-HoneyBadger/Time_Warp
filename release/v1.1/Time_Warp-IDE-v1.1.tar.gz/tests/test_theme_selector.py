#!/usr/bin/env python3
"""
Test Theme Selector for Time_Warp IDE v1.0.1
Demonstrates the theme changing functionality
"""

import sys
import os
import time
import threading

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tools.theme import get_theme_colors, load_config, save_config

def test_theme_colors():
    """Test loading different theme colors"""
    print("🎨 Testing Theme Color System")
    print("=" * 50)
    
    themes = ["dracula", "monokai", "solarized", "ocean", "spring", "sunset", "candy", "forest"]
    
    for theme_name in themes:
        colors = get_theme_colors(theme_name)
        print(f"\n🎨 {theme_name.upper()} Theme:")
        print(f"   Background: {colors['bg_primary']}")
        print(f"   Text: {colors['text_primary']}")
        print(f"   Accent: {colors['accent']}")
        print(f"   Selection: {colors['selection']}")

def test_config_persistence():
    """Test theme config saving and loading"""
    print("\n🔧 Testing Config Persistence")
    print("=" * 50)
    
    # Load current config
    config = load_config()
    original_theme = config.get('current_theme', 'dracula')
    print(f"Original theme: {original_theme}")
    
    # Test changing and saving theme
    test_theme = "monokai" if original_theme != "monokai" else "sunset"
    config['current_theme'] = test_theme
    success = save_config(config)
    
    if success:
        print(f"✅ Successfully saved theme: {test_theme}")
        
        # Verify it was saved
        reloaded_config = load_config()
        saved_theme = reloaded_config.get('current_theme')
        
        if saved_theme == test_theme:
            print(f"✅ Theme persistence verified: {saved_theme}")
        else:
            print(f"❌ Theme persistence failed: expected {test_theme}, got {saved_theme}")
        
        # Restore original theme
        config['current_theme'] = original_theme
        save_config(config)
        print(f"🔄 Restored original theme: {original_theme}")
    else:
        print("❌ Failed to save config")

def demonstrate_theme_switching():
    """Demonstrate what theme switching looks like"""
    print("\n🎭 Demonstrating Theme Switching")
    print("=" * 50)
    
    dark_themes = ["dracula", "monokai", "solarized", "ocean"]
    light_themes = ["spring", "sunset", "candy", "forest"]
    
    print("🌙 DARK THEMES:")
    for theme in dark_themes:
        colors = get_theme_colors(theme)
        print(f"   {theme:12} | BG: {colors['bg_primary']:8} | Text: {colors['text_primary']:8} | Accent: {colors['accent']}")
    
    print("\n☀️ LIGHT THEMES:")
    for theme in light_themes:
        colors = get_theme_colors(theme)
        print(f"   {theme:12} | BG: {colors['bg_primary']:8} | Text: {colors['text_primary']:8} | Accent: {colors['accent']}")

def main():
    """Main test function"""
    print("🚀 Time_Warp IDE v1.0.1 - Theme Selector Test")
    print("=" * 60)
    
    try:
        test_theme_colors()
        test_config_persistence()
        demonstrate_theme_switching()
        
        print("\n✅ All theme tests completed successfully!")
        print("\n💡 To use theme selector in Time_Warp IDE:")
        print("   1. Launch Time_Warp IDE v1.0.1")
        print("   2. Go to View → Themes")
        print("   3. Select any theme from the menu")
        print("   4. Theme will apply immediately and save automatically")
        
    except Exception as e:
        print(f"❌ Test error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())