#!/usr/bin/env python3
"""
Test Python code for Time_Warp IDE v1.0.1
Demonstrates the new Python execution feature
"""

print("🐍 Python code execution test!")
print("=" * 40)

# Basic arithmetic
print("Math operations:")
print(f"2 + 3 = {2 + 3}")
print(f"10 * 5 = {10 * 5}")
print(f"2 ** 8 = {2 ** 8}")

# String operations
name = "Time_Warp IDE"
version = "v1.0.1"
print(f"\nString operations:")
print(f"IDE: {name}")
print(f"Version: {version}")
print(f"Full: {name} {version}")

# List operations
numbers = [1, 2, 3, 4, 5]
print(f"\nList operations:")
print(f"Numbers: {numbers}")
print(f"Sum: {sum(numbers)}")
print(f"Max: {max(numbers)}")

# Loop demonstration
print("\nLoop demonstration:")
for i in range(3):
    print(f"  Iteration {i + 1}")

# Function demonstration
def greet(name):
    return f"Hello, {name}!"

print(f"\nFunction result: {greet('Time_Warp User')}")

print("\n✅ Python execution test completed!")
print("This code was executed in Time_Warp IDE's new Python engine!")