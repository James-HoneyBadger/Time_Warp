#!/usr/bin/env python3
"""
Comprehensive Test Suite for Time_Warp IDE 1.1
Tests every command, function, setting, theme, and feature
"""

import unittest
import sys
import os
import tempfile
import shutil
from unittest.mock import Mock, patch, MagicMock
import tkinter as tk
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Test configuration
TEST_TIMEOUT = 30  # seconds per test
TEMP_TEST_DIR = None


class Time_WarpTestCase(unittest.TestCase):
    """Base test case with common setup"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment"""
        global TEMP_TEST_DIR
        TEMP_TEST_DIR = tempfile.mkdtemp(prefix='timewarp_test_')
        
        # Mock GUI to avoid display issues in headless testing
        cls.mock_tk_root = Mock()
        cls.mock_tk_root.mainloop = Mock()
        cls.mock_tk_root.destroy = Mock()
        
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment"""
        if TEMP_TEST_DIR and os.path.exists(TEMP_TEST_DIR):
            shutil.rmtree(TEMP_TEST_DIR, ignore_errors=True)
    
    def setUp(self):
        """Set up each test"""
        self.test_files = []
    
    def tearDown(self):
        """Clean up after each test"""
        for file_path in self.test_files:
            if os.path.exists(file_path):
                os.remove(file_path)


class TestCoreInterpreter(Time_WarpTestCase):
    """Test the core interpreter functionality"""
    
    def setUp(self):
        super().setUp()
        try:
            from core.interpreter import Time_WarpInterpreter
            self.interpreter = Time_WarpInterpreter()
        except ImportError:
            self.skipTest("Core interpreter not available")

    def test_interpreter_initialization(self):
        """Test interpreter initializes correctly"""
        self.assertIsNotNone(self.interpreter)
        self.assertTrue(hasattr(self.interpreter, 'run_program'))
        
    def test_pilot_language_basic(self):
        """Test basic PILOT language functionality"""
        test_program = "T:Hello, World!\nEND"
        result = self.interpreter.run_program(test_program, language='pilot')
        self.assertIsNotNone(result)
        
    def test_pilot_language_variables(self):
        """Test PILOT variable functionality"""
        test_program = """T:Enter your name:
A:#NAME
T:Hello, #NAME!
END"""
        # Mock input for testing
        with patch('builtins.input', return_value='TestUser'):
            result = self.interpreter.run_program(test_program, language='pilot')
            self.assertIsNotNone(result)
            
    def test_basic_language_simple(self):
        """Test BASIC language functionality"""
        test_program = """10 PRINT "Hello World"
20 END"""
        result = self.interpreter.run_program(test_program, language='basic')
        self.assertIsNotNone(result)
        
    def test_basic_language_math(self):
        """Test BASIC mathematics"""
        test_program = """10 LET A = 5
20 LET B = 3
30 PRINT A + B
40 END"""
        result = self.interpreter.run_program(test_program, language='basic')
        self.assertIsNotNone(result)
        
    def test_logo_language_basic(self):
        """Test Logo language functionality"""
        test_program = """FORWARD 50
RIGHT 90
FORWARD 50"""
        result = self.interpreter.run_program(test_program, language='logo')
        self.assertIsNotNone(result)
        
    def test_python_language(self):
        """Test Python language support"""
        test_program = """print("Hello from Python")
x = 42
print(f"The answer is {x}")"""
        result = self.interpreter.run_program(test_program, language='python')
        self.assertIsNotNone(result)
        
    def test_javascript_language(self):
        """Test JavaScript language support"""
        test_program = """console.log("Hello from JavaScript");
var x = 42;
console.log("The answer is " + x);"""
        result = self.interpreter.run_program(test_program, language='javascript')
        self.assertIsNotNone(result)


class TestLanguageExecutors(Time_WarpTestCase):
    """Test individual language executors"""
    
    def test_pilot_executor_commands(self):
        """Test all PILOT commands"""
        try:
            from core.languages.pilot import PilotExecutor
            from core.interpreter import Time_WarpInterpreter
            
            interpreter = Time_WarpInterpreter()
            executor = PilotExecutor(interpreter)
            
            # Test T: command
            result = executor.execute_command("T:Test message")
            self.assertIsNotNone(result)
            
            # Test A: command (with mock input)
            with patch('builtins.input', return_value='test'):
                result = executor.execute_command("A:#VAR")
                self.assertIsNotNone(result)
                
            # Test M: command
            result = executor.execute_command("M:5 = 5")
            self.assertIsNotNone(result)
            
        except ImportError:
            self.skipTest("PILOT executor not available")
            
    def test_basic_executor_commands(self):
        """Test BASIC language commands"""
        try:
            from core.languages.basic import BasicExecutor
            from core.interpreter import Time_WarpInterpreter
            
            interpreter = Time_WarpInterpreter()
            executor = BasicExecutor(interpreter)
            
            # Test PRINT
            result = executor.execute_command("PRINT \"Hello\"")
            self.assertIsNotNone(result)
            
            # Test LET
            result = executor.execute_command("LET X = 10")
            self.assertIsNotNone(result)
            
            # Test simple math
            result = executor.execute_command("PRINT 2 + 3")
            self.assertIsNotNone(result)
            
        except ImportError:
            self.skipTest("BASIC executor not available")
            
    def test_logo_executor_commands(self):
        """Test Logo turtle commands"""
        try:
            from core.languages.logo import LogoExecutor
            from core.interpreter import Time_WarpInterpreter
            
            interpreter = Time_WarpInterpreter()
            executor = LogoExecutor(interpreter)
            
            # Test movement commands
            result = executor.execute_command("FORWARD 50")
            self.assertIsNotNone(result)
            
            result = executor.execute_command("RIGHT 90")
            self.assertIsNotNone(result)
            
            result = executor.execute_command("PENUP")
            self.assertIsNotNone(result)
            
            result = executor.execute_command("PENDOWN")
            self.assertIsNotNone(result)
            
        except ImportError:
            self.skipTest("Logo executor not available")


class TestThemeSystem(Time_WarpTestCase):
    """Test theme system functionality"""
    
    def test_theme_loading(self):
        """Test theme loading"""
        try:
            from tools.theme import ThemeManager, get_theme_colors
            
            # Test all 8 themes
            themes = ['dracula', 'monokai', 'solarized', 'ocean', 
                     'spring', 'sunset', 'candy', 'forest']
            
            for theme_name in themes:
                colors = get_theme_colors(theme_name)
                self.assertIsInstance(colors, dict)
                
                # Check required color keys
                required_keys = ['bg_primary', 'bg_secondary', 'text_primary', 
                               'text_secondary', 'accent', 'success', 'warning', 'error']
                for key in required_keys:
                    self.assertIn(key, colors, f"Theme {theme_name} missing {key}")
                    
        except ImportError:
            self.skipTest("Theme system not available")
            
    def test_theme_manager(self):
        """Test ThemeManager functionality"""
        try:
            from tools.theme import ThemeManager
            
            theme_manager = ThemeManager()
            
            # Test theme switching
            for theme in ['dracula', 'spring', 'monokai']:
                theme_manager.set_theme(theme)
                self.assertEqual(theme_manager.current_theme, theme)
                
        except ImportError:
            self.skipTest("ThemeManager not available")


class TestFeatureSystem(Time_WarpTestCase):
    """Test Features menu functionality"""
    
    def test_tutorial_system(self):
        """Test Tutorial System"""
        try:
            from core.features.tutorial_system import TutorialSystem
            
            tutorial = TutorialSystem()
            self.assertIsNotNone(tutorial)
            
            # Test tutorial data loading
            if hasattr(tutorial, 'get_tutorials'):
                tutorials = tutorial.get_tutorials()
                self.assertIsInstance(tutorials, (list, dict))
                
        except ImportError:
            self.skipTest("Tutorial system not available")
            
    def test_ai_assistant(self):
        """Test AI Assistant"""
        try:
            from core.features.ai_assistant import AICodeAssistant
            
            assistant = AICodeAssistant()
            self.assertIsNotNone(assistant)
            
            # Test code analysis
            if hasattr(assistant, 'analyze_code'):
                result = assistant.analyze_code("print('hello')", 'python')
                self.assertIsNotNone(result)
                
        except ImportError:
            self.skipTest("AI assistant not available")
            
    def test_gamification_system(self):
        """Test Gamification System"""
        try:
            from core.features.gamification import GamificationSystem
            
            gamification = GamificationSystem()
            self.assertIsNotNone(gamification)
            
            # Test achievement system
            if hasattr(gamification, 'check_achievements'):
                achievements = gamification.check_achievements()
                self.assertIsInstance(achievements, (list, dict))
                
        except ImportError:
            self.skipTest("Gamification system not available")


class TestMultiTabEditor(Time_WarpTestCase):
    """Test multi-tab editor functionality"""
    
    @patch('tkinter.Tk')
    @patch('tkinter.ttk.Notebook')
    def test_editor_initialization(self, mock_notebook, mock_tk):
        """Test multi-tab editor initialization"""
        try:
            from gui.components.multi_tab_editor import MultiTabEditor
            
            mock_parent = Mock()
            editor = MultiTabEditor(mock_parent)
            self.assertIsNotNone(editor)
            
        except ImportError:
            self.skipTest("Multi-tab editor not available")
            
    def test_language_detection(self):
        """Test automatic language detection"""
        try:
            from gui.components.multi_tab_editor import TabEditor
            
            # Mock the tkinter components
            with patch('tkinter.ttk.Frame'), patch('tkinter.Text'), patch('tkinter.ttk.Notebook'):
                mock_notebook = Mock()
                tab = TabEditor(mock_notebook)
                
                if hasattr(tab, 'detect_and_set_language'):
                    # Test extension-based detection
                    tab.file_path = "test.py"
                    tab.detect_and_set_language()
                    
                    tab.file_path = "test.pilot"
                    tab.detect_and_set_language()
                    
        except ImportError:
            self.skipTest("Tab editor not available")


class TestFileOperations(Time_WarpTestCase):
    """Test file loading, saving, and management"""
    
    def test_file_creation(self):
        """Test creating new files"""
        test_file = os.path.join(TEMP_TEST_DIR, 'test.pilot')
        content = "T:This is a test\nEND"
        
        with open(test_file, 'w') as f:
            f.write(content)
            
        self.assertTrue(os.path.exists(test_file))
        
        with open(test_file, 'r') as f:
            read_content = f.read()
            
        self.assertEqual(content, read_content)
        self.test_files.append(test_file)
        
    def test_file_extensions(self):
        """Test various file extensions"""
        extensions = ['.pilot', '.bas', '.basic', '.logo', '.py', '.js', '.pl']
        
        for ext in extensions:
            test_file = os.path.join(TEMP_TEST_DIR, f'test{ext}')
            with open(test_file, 'w') as f:
                f.write(f"# Test file for {ext}")
            
            self.assertTrue(os.path.exists(test_file))
            self.test_files.append(test_file)


class TestErrorHandling(Time_WarpTestCase):
    """Test error handling and edge cases"""
    
    def test_invalid_syntax(self):
        """Test handling of invalid syntax"""
        try:
            from core.interpreter import Time_WarpInterpreter
            interpreter = Time_WarpInterpreter()
            
            # Test invalid PILOT syntax
            result = interpreter.run_program("INVALID_COMMAND", language='pilot')
            # Should not crash, may return None or error result
            
            # Test invalid BASIC syntax  
            result = interpreter.run_program("10 INVALID COMMAND", language='basic')
            # Should not crash
            
        except ImportError:
            self.skipTest("Core interpreter not available")
            
    def test_empty_programs(self):
        """Test handling of empty programs"""
        try:
            from core.interpreter import Time_WarpInterpreter
            interpreter = Time_WarpInterpreter()
            
            # Test empty string
            result = interpreter.run_program("", language='pilot')
            
            # Test whitespace only
            result = interpreter.run_program("   \n\t  ", language='basic')
            
        except ImportError:
            self.skipTest("Core interpreter not available")


class TestIntegration(Time_WarpTestCase):
    """Integration tests for complete workflows"""
    
    @patch('tkinter.Tk')
    def test_main_application_init(self, mock_tk):
        """Test main application initialization"""
        try:
            # Mock GUI components to avoid display requirements
            with patch.multiple('tkinter.ttk',
                              Frame=Mock,
                              Label=Mock,
                              Button=Mock,
                              Notebook=Mock,
                              PanedWindow=Mock):
                with patch('tkinter.scrolledtext.ScrolledText', Mock):
                    with patch('tkinter.Menu', Mock):
                        # Import should not fail
                        import Time_Warp
                        
                        # Basic smoke test - class should be importable
                        self.assertTrue(hasattr(Time_Warp, 'Time_WarpIDE'))
                        
        except Exception as e:
            # Log but don't fail - GUI tests are tricky in headless environment
            print(f"Main application test warning: {e}")


def run_comprehensive_tests():
    """Run all comprehensive tests"""
    print("🧪 Time_Warp IDE 1.1 - Comprehensive Test Suite")
    print("=" * 60)
    
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    test_classes = [
        TestCoreInterpreter,
        TestLanguageExecutors, 
        TestThemeSystem,
        TestFeatureSystem,
        TestMultiTabEditor,
        TestFileOperations,
        TestErrorHandling,
        TestIntegration
    ]
    
    for test_class in test_classes:
        tests = loader.loadTestsFromTestCase(test_class)
        suite.addTests(tests)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2, buffer=True)
    result = runner.run(suite)
    
    # Print summary
    print("\n" + "=" * 60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Skipped: {len(result.skipped) if hasattr(result, 'skipped') else 0}")
    
    if result.failures:
        print("\n❌ FAILURES:")
        for test, traceback in result.failures:
            print(f"  - {test}: {traceback.split(chr(10))[-2] if chr(10) in traceback else traceback}")
    
    if result.errors:
        print("\n💥 ERRORS:")
        for test, traceback in result.errors:
            print(f"  - {test}: {traceback.split(chr(10))[-2] if chr(10) in traceback else traceback}")
    
    success = len(result.failures) == 0 and len(result.errors) == 0
    
    if success:
        print("\n✅ All tests passed! Time_Warp IDE 1.1 is ready for release!")
    else:
        print(f"\n⚠️ Some tests had issues. Review failures and errors above.")
    
    return success, result


if __name__ == '__main__':
    success, result = run_comprehensive_tests()
    sys.exit(0 if success else 1)