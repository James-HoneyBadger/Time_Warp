#!/usr/bin/env python3
"""Quick test of BASIC graphics functionality"""

from core.interpreter import Time_WarpInterpreter

def test_graphics():
    # Create interpreter
    interp = Time_WarpInterpreter()
    
    print("Testing BASIC graphics commands...")
    
    # Test basic graphics commands
    commands = [
        "GAMESCREEN 600, 400",
        "GAMEBG 0, 0, 128", 
        "GAMECOLOR 255, 255, 0",
        "GAMERECT 50, 50, 100, 30",
        "GAMECOLOR 255, 0, 0", 
        "GAMECIRCLE 200, 100, 25",
        "GAMECOLOR 0, 255, 0",
        "GAMEPOINT 300, 150",
        "GAMETEXT 400, 200, \"HELLO WORLD\"",
        "GAMEUPDATE"
    ]
    
    print("Executing graphics commands:")
    for cmd in commands:
        print(f"  {cmd}")
        result = interp.execute_line(cmd)
        if result == "error":
            print(f"    ERROR executing: {cmd}")
    
    print("\nGraphics test complete. Check if window appeared with graphics.")
    
    # Keep the program running for a bit
    import time
    print("Waiting 5 seconds...")
    time.sleep(5)

if __name__ == "__main__":
    test_graphics()