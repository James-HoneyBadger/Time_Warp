#!/usr/bin/env python3
"""
Test script to check Theme Selector and Settings functionality
"""
import tkinter as tk
from tkinter import messagebox
import sys
import os

# Add current directory to path
sys.path.append('.')

try:
    # Import Time_Warp
    from Time_Warp import Time_Warp
    
    def test_theme_selector():
        """Test theme selector"""
        print("Testing theme selector...")
        try:
            app = Time_Warp()
            app.show_theme_selector()
            print("✅ Theme selector works!")
            return True
        except Exception as e:
            print(f"❌ Theme selector error: {e}")
            import traceback
            traceback.print_exc()
            return False
            
    def test_settings():
        """Test settings"""
        print("Testing settings...")
        try:
            app = Time_Warp()
            app.show_settings()
            print("✅ Settings works!")
            return True
        except Exception as e:
            print(f"❌ Settings error: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def test_menu_integration():
        """Test menu integration"""
        print("Testing menu integration...")
        try:
            app = Time_Warp()
            
            # Create a test window to verify menu commands
            root = app.root
            
            # Test if the methods exist
            if hasattr(app, 'show_theme_selector'):
                print("✅ show_theme_selector method exists")
            else:
                print("❌ show_theme_selector method missing")
                
            if hasattr(app, 'show_settings'):
                print("✅ show_settings method exists")
            else:
                print("❌ show_settings method missing")
            
            # Test menu bar
            if hasattr(app, 'menubar'):
                print("✅ menubar exists")
            else:
                print("❌ menubar missing")
                
            return True
        except Exception as e:
            print(f"❌ Menu integration error: {e}")
            import traceback
            traceback.print_exc()
            return False

    if __name__ == "__main__":
        print("🧪 Testing Time_Warp Menu Functionality")
        print("=" * 40)
        
        # Test individual components
        test_menu_integration()
        
        print("\n" + "=" * 40)
        print("Tests completed!")
        
except Exception as e:
    print(f"❌ Import error: {e}")
    import traceback
    traceback.print_exc()