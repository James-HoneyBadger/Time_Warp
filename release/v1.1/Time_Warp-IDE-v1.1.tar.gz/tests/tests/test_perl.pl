#!/usr/bin/perl
print "Hello from Perl in Time_Warp IDE!\n";
my $name = "Time_Warp";
print "Welcome to $name IDE with Perl support\n";