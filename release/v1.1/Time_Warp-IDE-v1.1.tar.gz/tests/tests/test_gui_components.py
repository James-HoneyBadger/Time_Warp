#!/usr/bin/env python3
"""
Test script for the GUI components extraction
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, '/path/to/time_warp')

try:
    # Test importing GUI components
    from gui.components import (
        VirtualEnvironmentManager,
        ProjectExplorer,
        EducationalTutorials,
        ExerciseMode,
        VersionControlSystem,
        AdvancedDebugger
    )
    print("✓ Successfully imported all GUI components")
    
    # Test creating component instances (with mock IDE)
    class MockIDE:
        def __init__(self):
            self.root = None
            self.editor = None
    
    mock_ide = MockIDE()
    
    # Test component instantiation
    venv_mgr = VirtualEnvironmentManager()
    print("✓ VirtualEnvironmentManager created")
    
    proj_explorer = ProjectExplorer(mock_ide)
    print("✓ ProjectExplorer created")
    
    tutorials = EducationalTutorials(mock_ide)
    print("✓ EducationalTutorials created")
    
    exercises = ExerciseMode(mock_ide)
    print("✓ ExerciseMode created")
    
    version_ctrl = VersionControlSystem(mock_ide)
    print("✓ VersionControlSystem created")
    
    debugger = AdvancedDebugger(mock_ide)
    print("✓ AdvancedDebugger created")
    
    print("\n🎉 All GUI component tests passed!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Error: {e}")
    sys.exit(1)