print("Hello from Python in Time_Warp IDE!")
name = "Time_Warp"
print(f"Welcome to {name} IDE with Python support")