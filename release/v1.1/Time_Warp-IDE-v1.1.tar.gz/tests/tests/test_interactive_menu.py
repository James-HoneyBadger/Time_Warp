#!/usr/bin/env python3
"""
Interactive test for Time_Warp menu items
"""
import tkinter as tk
import sys
import threading
import time

sys.path.append('.')

from Time_Warp import IDETimeWarp

def test_interactive():
    """Test menu items interactively"""
    print("🧪 Starting interactive Time_Warp test...")
    
    app = IDETimeWarp()
    
    def test_theme_after_start():
        """Test theme selector after GUI starts"""
        time.sleep(2)  # Wait for GUI to fully load
        print("Testing theme selector...")
        try:
            app.show_theme_selector()
            print("✅ Theme selector opened successfully!")
        except Exception as e:
            print(f"❌ Theme selector failed: {e}")
            
        time.sleep(2)
        print("Testing settings...")
        try:
            app.show_settings()
            print("✅ Settings opened successfully!")
        except Exception as e:
            print(f"❌ Settings failed: {e}")
            
        # Close after tests
        time.sleep(3)
        app.root.quit()
    
    # Start test in separate thread
    test_thread = threading.Thread(target=test_theme_after_start)
    test_thread.daemon = True
    test_thread.start()
    
    # Start GUI
    try:
        app.root.mainloop()
        print("✅ Time_Warp GUI ran successfully")
    except Exception as e:
        print(f"❌ GUI error: {e}")

if __name__ == "__main__":
    test_interactive()