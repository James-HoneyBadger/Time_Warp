"""
Time_Warp IDE Test Suite
Comprehensive testing framework for all Time_Warp IDE components
"""

__version__ = "1.0.0"
__author__ = "Time_Warp IDE Team"
