#!/usr/bin/env python3
"""
Test script to demonstrate the new theme system in Time_Warp IDE
"""

from tools.theme import get_theme_colors

def test_theme_colors():
    """Test all available theme colors"""
    themes = ['dracula', 'monokai', 'solarized', 'ocean']
    modes = [True, False]  # Dark and Light modes
    
    print("🎨 Time_Warp IDE Theme Color System Test")
    print("=" * 50)
    
    for theme in themes:
        print(f"\n🦋 {theme.upper()} THEME:")
        print("-" * 30)
        
        for dark_mode in modes:
            mode_name = "Dark" if dark_mode else "Light"
            colors = get_theme_colors(theme, dark_mode)
            
            print(f"\n  {mode_name} Mode:")
            print(f"    Background: {colors['bg_primary']}")
            print(f"    Text: {colors['text_primary']}")
            print(f"    Accent: {colors['accent']}")
            print(f"    Success: {colors['success']}")
            print(f"    Warning: {colors['warning']}")
            print(f"    Error: {colors['error']}")

if __name__ == "__main__":
    test_theme_colors()
    
    print("\n✨ Theme system test complete!")
    print("💡 Use the View → Color Theme menu in Time_Warp IDE to switch themes")