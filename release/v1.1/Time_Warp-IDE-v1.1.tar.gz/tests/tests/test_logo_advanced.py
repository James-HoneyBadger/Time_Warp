#!/usr/bin/env python3
"""
Advanced Logo interpreter test - testing turtle graphics and complex features
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import Time_WarpInterpreter

def test_logo_advanced():
    """Test advanced Logo features"""
    print("🔧 Testing Advanced Logo Features...")
    
    interpreter = Time_WarpInterpreter()
    
    # Test complex Logo program with REPEAT, colors, and shapes
    logo_program = """
CLEARSCREEN
HOME
SETCOLOR red
REPEAT 8 [ FORWARD 60 RIGHT 45 ]
PENUP
SETXY 100 100
PENDOWN
SETCOLOR blue
REPEAT 4 [ FORWARD 50 RIGHT 90 ]
HOME
SETCOLOR green
REPEAT 36 [ FORWARD 50 RIGHT 89 ]
HOME
"""
    
    print("Running Advanced Logo program:")
    print("--- OUTPUT ---")
    
    try:
        interpreter.run_program(logo_program)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("--- END OUTPUT ---\n")

if __name__ == "__main__":
    test_logo_advanced()