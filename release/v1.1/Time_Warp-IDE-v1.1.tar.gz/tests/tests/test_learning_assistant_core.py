#!/usr/bin/env python3
"""
Unit tests for Learning Assistant Plugin core components
Tests without UI dependencies
"""

import sys
import os
import tempfile
import json

# Add the project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from tools.plugins.learning_assistant.plugin import (
    CodeAnalyzer, TutorialManager, LearningPath
)


def test_code_analyzer_pilot():
    """Test PILOT code analysis"""
    print("🔧 Testing PILOT Code Analysis...")
    
    analyzer = CodeAnalyzer()
    
    # Good PILOT code
    good_code = """
    R: This program greets users
    *START
    T: Hello, World!
    A: #NAME
    T: Nice to meet you, #NAME!
    E:
    """
    
    result = analyzer.analyze_code(good_code, 'pilot')
    assert result['score'] > 70, f"Expected good score, got {result['score']}"
    assert result['quality'] in ['good', 'excellent'], f"Expected good quality, got {result['quality']}"
    
    # Poor PILOT code (no structure)
    poor_code = "T: Hello\nE:"
    
    result = analyzer.analyze_code(poor_code, 'pilot')
    assert result['score'] < 90, f"Expected lower score for poor code, got {result['score']}"
    assert len(result['suggestions']) > 0, "Expected suggestions for poor code"
    
    print("✅ PILOT analysis tests passed")


def test_code_analyzer_basic():
    """Test BASIC code analysis"""
    print("🔧 Testing BASIC Code Analysis...")
    
    analyzer = CodeAnalyzer()
    
    # Good BASIC code
    good_code = """
    10 REM Simple BASIC program
    20 PRINT "Hello, World!"
    30 INPUT "Enter name: "; NAME$
    40 PRINT "Hello, "; NAME$
    50 END
    """
    
    result = analyzer.analyze_code(good_code, 'basic')
    assert result['score'] > 50, f"Expected decent score, got {result['score']}"
    assert 'suggestions' in result
    
    print("✅ BASIC analysis tests passed")


def test_code_analyzer_logo():
    """Test Logo code analysis"""
    print("🔧 Testing Logo Code Analysis...")
    
    analyzer = CodeAnalyzer()
    
    # Good Logo code
    good_code = """
    ; Draw a square
    TO SQUARE
      REPEAT 4 [
        FORWARD 100
        RIGHT 90
      ]
    END
    
    HOME
    SQUARE
    """
    
    result = analyzer.analyze_code(good_code, 'logo')
    assert result['score'] > 70, f"Expected good score, got {result['score']}"
    
    print("✅ Logo analysis tests passed")


def test_tutorial_manager():
    """Test tutorial manager functionality"""
    print("📚 Testing Tutorial Manager...")
    
    manager = TutorialManager()
    
    # Test tutorials are loaded
    assert len(manager.tutorials) > 0, "No tutorials loaded"
    
    # Test tutorial structure
    for tutorial_id, tutorial in manager.tutorials.items():
        assert 'title' in tutorial, f"Tutorial {tutorial_id} missing title"
        assert 'language' in tutorial, f"Tutorial {tutorial_id} missing language"
        assert 'steps' in tutorial, f"Tutorial {tutorial_id} missing steps"
        assert len(tutorial['steps']) > 0, f"Tutorial {tutorial_id} has no steps"
        
        # Test step structure
        for i, step in enumerate(tutorial['steps']):
            assert 'title' in step, f"Step {i} in {tutorial_id} missing title"
            assert 'content' in step, f"Step {i} in {tutorial_id} missing content"
            assert 'code' in step, f"Step {i} in {tutorial_id} missing code"
            assert 'task' in step, f"Step {i} in {tutorial_id} missing task"
    
    # Test getting tutorials by language
    pilot_tutorials = manager.get_tutorials_for_language('pilot')
    basic_tutorials = manager.get_tutorials_for_language('basic')
    logo_tutorials = manager.get_tutorials_for_language('logo')
    
    assert len(pilot_tutorials) > 0, "No PILOT tutorials found"
    assert len(basic_tutorials) > 0, "No BASIC tutorials found"
    assert len(logo_tutorials) > 0, "No Logo tutorials found"
    
    # Test getting specific tutorial
    first_tutorial_id = list(manager.tutorials.keys())[0]
    tutorial = manager.get_tutorial(first_tutorial_id)
    assert tutorial is not None, "Could not get tutorial by ID"
    
    print("✅ Tutorial manager tests passed")


def test_learning_path():
    """Test learning path functionality"""
    print("🛤️ Testing Learning Path...")
    
    # Create a test learning path
    lessons = [
        {'type': 'tutorial', 'id': 'intro', 'title': 'Introduction'},
        {'type': 'practice', 'id': 'basic_exercises', 'title': 'Basic Exercises'},
        {'type': 'project', 'id': 'final_project', 'title': 'Final Project'}
    ]
    
    path = LearningPath("Test Path", "A test learning path", lessons)
    
    # Test initial state
    assert path.name == "Test Path"
    assert path.description == "A test learning path"
    assert len(path.lessons) == 3
    assert path.current_lesson == 0
    assert len(path.completed_lessons) == 0
    
    # Test completion
    path.completed_lessons.add(0)
    path.completed_lessons.add(1)
    assert len(path.completed_lessons) == 2
    
    # Test serialization
    path_dict = path.to_dict()
    assert 'name' in path_dict
    assert 'lessons' in path_dict
    assert 'completed_lessons' in path_dict
    
    # Test deserialization
    restored_path = LearningPath.from_dict(path_dict)
    assert restored_path.name == path.name
    assert len(restored_path.lessons) == len(path.lessons)
    assert restored_path.completed_lessons == path.completed_lessons
    
    print("✅ Learning path tests passed")


def test_code_analysis_comprehensive():
    """Test comprehensive code analysis across languages"""
    print("🔍 Testing Comprehensive Code Analysis...")
    
    analyzer = CodeAnalyzer()
    
    test_codes = {
        'pilot': {
            'excellent': '''
                R: Well-structured PILOT program with comments
                *MAIN
                T: Welcome to the Number Guessing Game!
                R: Generate random number and get user input
                A: #GUESS
                T: You guessed #GUESS
                *END
                T: Thanks for playing!
                E:
            ''',
            'poor': 'T: Hi\nE:'
        },
        'basic': {
            'excellent': '''
                10 REM Calculator Program - Version 1.0
                20 REM This program performs basic arithmetic
                30 PRINT "Calculator Program"
                40 INPUT "First number: "; FIRST_NUM
                50 INPUT "Second number: "; SECOND_NUM
                60 PRINT "Sum: "; FIRST_NUM + SECOND_NUM
                70 END
            ''',
            'poor': '10 PRINT "HI"'
        },
        'logo': {
            'excellent': '''
                ; Geometric art generator
                TO SQUARE :SIZE
                  REPEAT 4 [
                    FORWARD :SIZE
                    RIGHT 90
                  ]
                END
                
                HOME
                CLEARSCREEN
                SQUARE 100
            ''',
            'poor': 'FORWARD 50'
        }
    }
    
    for language, codes in test_codes.items():
        # Test excellent code
        result = analyzer.analyze_code(codes['excellent'], language)
        assert result['score'] >= 80, f"{language} excellent code should score 80+, got {result['score']}"
        
        # Test poor code
        result = analyzer.analyze_code(codes['poor'], language)
        assert result['score'] < 80, f"{language} poor code should score <80, got {result['score']}"
        assert len(result['suggestions']) > 0, f"{language} poor code should have suggestions"
    
    print("✅ Comprehensive code analysis tests passed")


def run_all_tests():
    """Run all unit tests"""
    print("🎓 Learning Assistant Plugin - Unit Tests")
    print("=" * 50)
    
    tests = [
        test_code_analyzer_pilot,
        test_code_analyzer_basic,
        test_code_analyzer_logo,
        test_tutorial_manager,
        test_learning_path,
        test_code_analysis_comprehensive
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            test_func()
            passed += 1
        except Exception as e:
            print(f"❌ {test_func.__name__} failed: {str(e)}")
            failed += 1
            import traceback
            traceback.print_exc()
    
    print(f"\n📊 Test Results:")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📈 Success Rate: {passed/(passed+failed)*100:.1f}%")
    
    if failed == 0:
        print("\n🎉 All tests passed! Learning Assistant core components are working correctly.")
        return True
    else:
        print(f"\n⚠️ {failed} test(s) failed. Please review the errors above.")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)