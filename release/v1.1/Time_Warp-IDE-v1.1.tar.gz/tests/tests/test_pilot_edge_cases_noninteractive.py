#!/usr/bin/env python3
"""
PILOT Interpreter Non-Interactive Edge Case Testing
==================================================

This script tests PILOT interpreter edge cases without requiring user input.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import Time_WarpInterpreter

def test_pilot_edge_cases():
    """Test PILOT interpreter edge cases"""
    print("🔧 Testing PILOT Interpreter Edge Cases...")
    
    test_cases = [
        {
            "name": "Variable Interpolation with Pre-set Variables",
            "program": """
T:Hello *NAME*
T:Your name is *NAME*  
T:Welcome to the system, *NAME*!
E:
""",
            "variables": {"NAME": "Alice"}
        },
        {
            "name": "Multiple Variable Interpolation",
            "program": """
T:*FIRST* *LAST* lives in *CITY*
T:*FIRST*'s email is *EMAIL*
T:Contact: *FIRST* *LAST* <*EMAIL*>
E:
""",
            "variables": {"FIRST": "John", "LAST": "Doe", "CITY": "Portland", "EMAIL": "john@example.com"}
        },
        {
            "name": "Empty and Special Variables",
            "program": """
T:Empty variable: '*EMPTY*'
T:Number variable: *NUMBER*
T:Special chars: *SPECIAL*
T:With spaces: '*SPACED*'
E:
""",
            "variables": {"EMPTY": "", "NUMBER": "42", "SPECIAL": "!@#$%", "SPACED": "hello world"}
        },
        {
            "name": "Undefined Variable Handling",
            "program": """
T:Defined variable: *DEFINED*
T:Undefined variable: *UNDEFINED*
T:Another defined: *DEFINED*
T:Another undefined: *MISSING*
T:Back to normal text
E:
""",
            "variables": {"DEFINED": "I exist"}
        },
        {
            "name": "Text Formatting Edge Cases",
            "program": """
T:
T:Empty T: command above
T:Line with trailing spaces    
T:	Line with tab
T:Line with "quotes" and symbols !@#$%^&*()
T:Unicode test: ñáéíóú
T:Very long line that might cause wrapping issues in the display system: Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
E:
""",
            "variables": {}
        },
        {
            "name": "Variable Name Edge Cases",
            "program": """
T:Single: *A*
T:Number suffix: *VAR1*
T:Long name: *VERY_LONG_VARIABLE_NAME*
T:All caps: *UPPERCASE*
T:Mixed case: *MixedCase*
E:
""",
            "variables": {"A": "single", "VAR1": "with1", "VERY_LONG_VARIABLE_NAME": "lengthy", "UPPERCASE": "caps", "MIXEDCASE": "mixed"}
        },
        {
            "name": "Nested and Complex Interpolation",
            "program": """
T:Simple: *NAME*
T:In sentence: Hello *NAME*, welcome!
T:Multiple in line: *FIRST* and *SECOND* are here
T:At start *PREFIX* and end *SUFFIX*
T:Adjacent: *A**B**C*
T:With punctuation: *NAME*, *TITLE*.
E:
""",
            "variables": {"NAME": "Alice", "FIRST": "Tom", "SECOND": "Jerry", "PREFIX": "Start", "SUFFIX": "End", "A": "1", "B": "2", "C": "3", "TITLE": "Dr"}
        },
        {
            "name": "Error Recovery and Robustness",
            "program": """
T:Normal text before error
T:Malformed: *BROKEN
T:Normal text after error
T:Another malformed: MISSING*
T:Unclosed: *UNCLOSED
T:Valid again: *VALID*
T:Final message
E:
""",
            "variables": {"VALID": "working"}
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n--- Test {i}: {test_case['name']} ---")
        interpreter = Time_WarpInterpreter()
        
        # Pre-populate variables
        interpreter.variables.update(test_case.get('variables', {}))
        
        try:
            print("Program:")
            for line in test_case['program'].strip().split('\n'):
                if line.strip():
                    print(f"  {line}")
            print(f"\nPre-set variables: {test_case.get('variables', {})}")
            print("\nOutput:")
            
            interpreter.run_program(test_case['program'])
            print("✅ Test completed successfully")
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
        print("-" * 50)

if __name__ == "__main__":
    test_pilot_edge_cases()