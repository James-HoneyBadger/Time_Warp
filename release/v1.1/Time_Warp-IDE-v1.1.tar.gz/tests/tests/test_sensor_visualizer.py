#!/usr/bin/env python3
"""
Test the Sensor Visualizer Plugin
"""

import sys
import os

# Add the current directory to Python path for imports
sys.path.append('/path/to/time_warp')
sys.path.append('/path/to/time_warp/tools/plugins/sensor_visualizer')

# Test imports
try:
    from tools.plugins.sensor_visualizer.plugin import SensorVisualizerPlugin
    print("✅ Sensor Visualizer plugin imported successfully")
except ImportError as e:
    print(f"❌ Failed to import Sensor Visualizer plugin: {e}")
    sys.exit(1)

# Test plugin creation
try:
    # Create a mock IDE instance
    class MockIDE:
        def __init__(self):
            self.title = "Mock Time_Warp IDE"
        
    # Create a mock framework
    class MockFramework:
        def __init__(self):
            self.event_manager = MockEventManager()
            self.registry = MockRegistry()
    
    class MockEventManager:
        def subscribe(self, event_name, callback):
            print(f"Event subscribed: {event_name}")
    
    class MockRegistry:
        def register(self, name, component):
            print(f"Component registered: {name}")
    
    # Test plugin instantiation
    mock_ide = MockIDE()
    mock_framework = MockFramework()
    
    plugin = SensorVisualizerPlugin(mock_ide, mock_framework)
    print("✅ Sensor Visualizer plugin created successfully")
    
    # Test plugin metadata
    print(f"Plugin Name: {plugin.name}")
    print(f"Plugin Version: {plugin.version}")
    print(f"Plugin Author: {plugin.author}")
    print(f"Plugin Category: {plugin.category}")
    print(f"Plugin Description: {plugin.description}")
    
    # Test plugin initialization
    if plugin.initialize():
        print("✅ Sensor Visualizer plugin initialized successfully")
    else:
        print("❌ Sensor Visualizer plugin initialization failed")
    
    # Test plugin activation
    if plugin.activate():
        print("✅ Sensor Visualizer plugin activated successfully")
    else:
        print("❌ Sensor Visualizer plugin activation failed")
    
    # Test plugin deactivation
    if plugin.deactivate():
        print("✅ Sensor Visualizer plugin deactivated successfully")
    else:
        print("❌ Sensor Visualizer plugin deactivation failed")
    
    print("\n🎉 All Sensor Visualizer plugin tests passed!")
    
except Exception as e:
    print(f"❌ Error testing Sensor Visualizer plugin: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)