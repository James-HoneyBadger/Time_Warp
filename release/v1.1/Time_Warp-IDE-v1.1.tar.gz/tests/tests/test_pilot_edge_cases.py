#!/usr/bin/env python3
"""
PILOT Interpreter Edge Case Testing
==================================

This script tests various edge cases and boundary conditions in the PILOT interpreter
to identify potential issues that could cause serious problems in educational programs.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import Time_WarpInterpreter

def test_pilot_edge_cases():
    """Test PILOT interpreter edge cases"""
    print("🔧 Testing PILOT Interpreter Edge Cases...")
    
    test_cases = [
        {
            "name": "Variable Interpolation Edge Cases",
            "program": """
T:Hello *NAME*
A:NAME
T:Your name is *NAME*
T:Length test: *LEN*
A:LEN
T:*LEN* characters
T:Multiple vars: *NAME* has *LEN* letters
E:
"""
        },
        {
            "name": "Empty and Special Character Variables",
            "program": """
T:Enter nothing and press enter:
A:EMPTY
T:Empty variable contains: '*EMPTY*'
T:Enter a space:
A:SPACE
T:Space variable contains: '*SPACE*'
T:Testing special chars
A:SPECIAL
T:Special contains: '*SPECIAL*'
E:
"""
        },
        {
            "name": "Nested Variable References",
            "program": """
T:Enter first name:
A:FIRST
T:Enter last name:
A:LAST
T:*FIRST* *LAST*
T:Hello *FIRST* *LAST*, welcome!
E:
"""
        },
        {
            "name": "Variable with Numeric Content",
            "program": """
T:Enter a number:
A:NUMBER
T:You entered: *NUMBER*
T:Double check: *NUMBER*
T:Number context: The value is *NUMBER*
E:
"""
        },
        {
            "name": "Long Text and Formatting",
            "program": """
T:This is a very long line of text that might cause formatting issues or wrapping problems in the PILOT interpreter system.
T:Enter your bio:
A:BIO
T:Bio: *BIO*
E:
"""
        },
        {
            "name": "Command Edge Cases",
            "program": """
T:Testing T: command with various content
T:
T:Empty T: above
T:Line with trailing spaces    
T:	Line with tab characters
T:Line with "quotes" and symbols !@#$%^&*()
E:
"""
        },
        {
            "name": "Variable Name Edge Cases",
            "program": """
T:Testing variable names
A:A
T:Single char: *A*
A:VAR1
T:With number: *VAR1*
A:LONG_VARIABLE_NAME
T:Long name: *LONG_VARIABLE_NAME*
E:
"""
        },
        {
            "name": "Error Recovery Cases", 
            "program": """
T:Testing undefined variable: *UNDEFINED*
T:Testing malformed interpolation: *BROKEN
T:Normal text after error
T:Another undefined: *MISSING*
T:Final message
E:
"""
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n--- Test {i}: {test_case['name']} ---")
        interpreter = Time_WarpInterpreter()
        
        try:
            print("Program:")
            for line in test_case['program'].strip().split('\n'):
                if line.strip():
                    print(f"  {line}")
            print("\nOutput:")
            
            # For PILOT programs, we need to simulate user input for A: commands
            # In a real test, we'd mock input, but for now we'll just run it
            interpreter.run_program(test_case['program'])
            print("✅ Test completed")
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
        print("-" * 50)

if __name__ == "__main__":
    test_pilot_edge_cases()