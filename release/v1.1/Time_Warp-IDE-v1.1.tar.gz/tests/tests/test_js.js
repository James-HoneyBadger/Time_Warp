console.log("Hello from JavaScript in Time_Warp IDE!");
const name = "Time_Warp";
console.log(`Welcome to ${name} IDE with JavaScript support`);