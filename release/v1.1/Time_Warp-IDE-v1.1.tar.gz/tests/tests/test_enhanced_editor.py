#!/usr/bin/env python3
"""
Test the Enhanced Code Editor functionality
"""

import sys
import os
import tkinter as tk
from tkinter import ttk

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.editor.enhanced_editor import EnhancedCodeEditor


def test_enhanced_editor():
    """Test the enhanced code editor"""
    
    # Create test window
    root = tk.Tk()
    root.title("Enhanced Code Editor Test")
    root.geometry("1200x800")
    
    # Create notebook for testing multiple languages
    notebook = ttk.Notebook(root)
    notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    # Test PILOT editor
    pilot_frame = ttk.Frame(notebook)
    notebook.add(pilot_frame, text="PILOT")
    pilot_editor = EnhancedCodeEditor(pilot_frame, initial_language="pilot")
    pilot_editor.set_content("""*START
T: Welcome to PILOT programming!
A: #NAME
T: Hello, #NAME!
J: *END
*END
E:""")
    
    # Test BASIC editor
    basic_frame = ttk.Frame(notebook)
    notebook.add(basic_frame, text="BASIC")
    basic_editor = EnhancedCodeEditor(basic_frame, initial_language="basic")
    basic_editor.set_content("""10 PRINT "Hello, World!"
20 INPUT "Enter your name: "; N$
30 PRINT "Hello, "; N$
40 FOR I = 1 TO 10
50   PRINT I
60 NEXT I
70 END""")
    
    # Test Logo editor
    logo_frame = ttk.Frame(notebook)
    notebook.add(logo_frame, text="Logo")
    logo_editor = EnhancedCodeEditor(logo_frame, initial_language="logo")
    logo_editor.set_content("""TO SQUARE :SIZE
  REPEAT 4 [
    FORWARD :SIZE
    RIGHT 90
  ]
END

TO FLOWER
  REPEAT 8 [
    SQUARE 50
    RIGHT 45
  ]
END

FLOWER""")
    
    # Test Python editor
    python_frame = ttk.Frame(notebook)
    notebook.add(python_frame, text="Python")
    python_editor = EnhancedCodeEditor(python_frame, initial_language="python")
    python_editor.set_content("""def fibonacci(n):
    \"\"\"Generate Fibonacci sequence up to n\"\"\"
    a, b = 0, 1
    while a < n:
        print(a, end=' ')
        a, b = b, a + b
    print()

if __name__ == "__main__":
    fibonacci(100)""")
    
    # Add status label
    status_label = ttk.Label(root, text="Enhanced Code Editor Test - Try editing code in different languages!")
    status_label.pack(pady=5)
    
    # Set up output callback for all editors
    def output_callback(message):
        print(f"Editor Output: {message}")
        status_label.config(text=message)
    
    pilot_editor.set_output_callback(output_callback)
    basic_editor.set_output_callback(output_callback)
    logo_editor.set_output_callback(output_callback)
    python_editor.set_output_callback(output_callback)
    
    print("✅ Enhanced Code Editor Test Started")
    print("🎯 Features to test:")
    print("  - Language-specific syntax highlighting")
    print("  - Code completion (Ctrl+Space)")
    print("  - Syntax checking")
    print("  - Code formatting (Format button)")
    print("  - Auto-indentation")
    print("  - Compilation (for PILOT, BASIC, Logo)")
    print("  - Find/Replace (Ctrl+F, Ctrl+H)")
    print("  - Multiple language support")
    
    root.mainloop()


if __name__ == "__main__":
    test_enhanced_editor()