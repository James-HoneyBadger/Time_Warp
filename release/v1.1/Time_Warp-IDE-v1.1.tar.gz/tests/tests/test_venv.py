#!/usr/bin/env python3
# Test script to verify Time_Warp virtual environment auto-activation

import sys
import os

print("🧪 Testing Time_Warp virtual environment auto-activation...")
print(f"Current Python executable: {sys.executable}")

# Test PIL import
try:
    from PIL import Image, ImageTk
    print("✅ PIL import successful!")
    import PIL
    print(f"PIL version: {PIL.__version__}")
    print("🎉 Time_Warp virtual environment is working correctly!")
except ImportError as e:
    print(f"❌ PIL import failed: {e}")
    print("This indicates the virtual environment is not being used.")