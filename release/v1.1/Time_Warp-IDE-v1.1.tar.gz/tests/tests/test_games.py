#!/usr/bin/env python3
"""
Test script for the games module extraction
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, '/path/to/time_warp')

try:
    # Test importing game engine components
    from games.engine import GameObject, Vector2D, GameRenderer, GameManager, PhysicsEngine
    print("✓ Successfully imported game engine components")
    
    # Test creating component instances
    vector = Vector2D(10, 20)
    print(f"✓ Vector2D created: ({vector.x}, {vector.y})")
    
    game_obj = GameObject(50, 100, 32, 32)
    print(f"✓ GameObject created at ({game_obj.position.x}, {game_obj.position.y})")
    
    renderer = GameRenderer()
    print("✓ GameRenderer created")
    
    physics = PhysicsEngine()
    print("✓ PhysicsEngine created")
    
    game_mgr = GameManager()
    print("✓ GameManager created")
    
    # Test some basic functionality
    game_mgr.create_object("player", "character", 100, 200, 32, 32, "red")
    player = game_mgr.get_object("player")
    if player:
        print(f"✓ Created player object at ({player.position.x}, {player.position.y})")
    
    # Test physics integration
    physics.add_object(game_obj)
    print("✓ Added object to physics engine")
    
    print("\n🎉 All game engine tests passed!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Error: {e}")
    sys.exit(1)