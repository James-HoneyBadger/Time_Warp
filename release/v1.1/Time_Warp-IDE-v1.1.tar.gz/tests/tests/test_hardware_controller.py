#!/usr/bin/env python3
"""
Test the Hardware Controller plugin specifically
"""

import sys
import os
import tkinter as tk
from tkinter import ttk

# Add Time_Warp directory to path
sys.path.insert(0, os.path.dirname(__file__))

from core.framework import Time_WarpFramework
from tools.tool_manager import ToolManager

# Mock IDE instance
class MockIDE:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🧪 Hardware Controller Test")
        self.root.geometry("900x700")
        
        self.interpreter = None
        self.menu_items = []
        self.toolbar_items = []
    
    def add_tool_menu_item(self, path, label, command, accelerator=None):
        self.menu_items.append({'path': path, 'label': label, 'command': command, 'accelerator': accelerator})
        print(f"📋 Added menu item: {path} → {label}")
    
    def add_tool_toolbar_item(self, label, command, icon=None, tooltip=None):
        self.toolbar_items.append({'label': label, 'command': command, 'icon': icon, 'tooltip': tooltip})
        print(f"🔧 Added toolbar item: {label}")
    
    def remove_tool_menu_item(self, path, label):
        print(f"🗑️ Removed menu item: {path} → {label}")
    
    def remove_tool_toolbar_item(self, label):
        print(f"🗑️ Removed toolbar item: {label}")

def test_hardware_controller():
    """Test the Hardware Controller plugin"""
    print("🔌 Testing Hardware Controller Plugin...")
    
    # Setup
    mock_ide = MockIDE()
    framework = Time_WarpFramework(mock_ide)
    tool_manager = ToolManager(mock_ide, framework)
    
    # Load Hardware Controller
    success = tool_manager.load_tool('hardware_controller')
    if success:
        print("✅ Hardware Controller loaded successfully")
        
        # Activate
        activation_success = tool_manager.activate_tool('hardware_controller')
        if activation_success:
            print("✅ Hardware Controller activated successfully")
            
            # Show tool
            show_success = tool_manager.show_tool('hardware_controller')
            if show_success:
                print("✅ Hardware Controller UI shown successfully")
                
                # Create test UI
                main_frame = ttk.Frame(mock_ide.root)
                main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
                
                ttk.Label(main_frame, text="🔌 Hardware Controller Test", 
                         font=("Arial", 16, "bold")).pack(pady=10)
                
                ttk.Label(main_frame, text="Hardware Controller is running!\n"
                                          "Check the separate window for the full interface.\n\n"
                                          "Features available:\n"
                                          "• 📌 GPIO Pin Control\n"
                                          "• 🌡️ Sensor Management\n"
                                          "• 🔧 Device Control\n"
                                          "• 🤖 Automation Engine",
                         font=("Arial", 12), justify=tk.CENTER).pack(pady=20)
                
                ttk.Button(main_frame, text="❌ Close Test", 
                          command=mock_ide.root.quit).pack(pady=20)
                
                print("🚀 Starting Hardware Controller interactive test...")
                mock_ide.root.mainloop()
                
            else:
                print("❌ Could not show Hardware Controller UI")
        else:
            print("❌ Failed to activate Hardware Controller")
    else:
        print("❌ Failed to load Hardware Controller")

if __name__ == "__main__":
    test_hardware_controller()