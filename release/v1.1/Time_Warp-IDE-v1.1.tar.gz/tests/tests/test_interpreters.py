#!/usr/bin/env python3
"""
Direct test of Time_Warp interpreters without GUI
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import Time_WarpInterpreter

def test_pilot_interpreter():
    """Test PILOT interpreter functionality"""
    print("🔧 Testing PILOT Interpreter...")
    
    # Create interpreter instance
    interpreter = Time_WarpInterpreter()
    
    # Test basic PILOT commands
    pilot_program = """
T:Testing PILOT Interpreter
T:This tests basic PILOT functionality
U:NAME=TestUser
T:Hello *NAME*!
U:AGE=25  
T:Your age is *AGE*
C:RESULT=10+5
T:10 + 5 = *RESULT*
END
"""
    
    print("Running PILOT program:")
    print(pilot_program.strip())
    print("\n--- OUTPUT ---")
    
    # Execute the program using run_program method
    try:
        interpreter.run_program(pilot_program)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("--- END OUTPUT ---\n")

def test_basic_interpreter():
    """Test BASIC interpreter functionality"""
    print("🔧 Testing BASIC Interpreter...")
    
    # Create interpreter instance
    interpreter = Time_WarpInterpreter()
    
    # Test basic BASIC commands
    basic_program = """
PRINT "Testing BASIC Interpreter"
LET X = 10
LET Y = 20
LET Z = X + Y
PRINT "X ="; X; "Y ="; Y; "Z ="; Z
FOR I = 1 TO 3
    PRINT "Count: "; I
NEXT I
END
"""
    
    print("Running BASIC program:")
    print(basic_program.strip())
    print("\n--- OUTPUT ---")
    
    # Execute the program using run_program method
    try:
        interpreter.run_program(basic_program)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("--- END OUTPUT ---\n")

def test_logo_interpreter():
    """Test Logo interpreter functionality"""
    print("🔧 Testing Logo Interpreter...")
    
    # Create interpreter instance
    interpreter = Time_WarpInterpreter()
    
    # Test basic Logo commands
    logo_program = """
CLEARSCREEN
HOME
FORWARD 50
RIGHT 90
FORWARD 50
RIGHT 90  
FORWARD 50
RIGHT 90
FORWARD 50
PENUP
HOME
PENDOWN
"""
    
    print("Running Logo program:")
    print(logo_program.strip())
    print("\n--- OUTPUT ---")
    
    # Execute the program using run_program method
    try:
        interpreter.run_program(logo_program)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("--- END OUTPUT ---\n")

if __name__ == "__main__":
    print("=== TIMEWARP INTERPRETER VERIFICATION ===\n")
    
    test_pilot_interpreter()
    test_basic_interpreter()
    test_logo_interpreter()
    
    print("=== VERIFICATION COMPLETE ===")