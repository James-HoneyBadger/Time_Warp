#!/usr/bin/env python3
"""
Time_Warp Dependency Test
Tests that all required dependencies are working correctly
"""

import sys
import os

def test_imports():
    """Test that all required modules can be imported"""
    print("🧪 Testing Time_Warp Dependencies")
    print("=" * 40)
    
    tests = []
    
    # Test PIL/Pillow
    try:
        from PIL import Image, ImageTk
        tests.append(("✅ PIL/Pillow", "Image processing available"))
    except ImportError:
        tests.append(("❌ PIL/Pillow", "Image processing unavailable"))
    
    # Test pygame
    try:
        import pygame
        tests.append(("✅ Pygame", "Game development and audio available"))
    except ImportError:
        tests.append(("❌ Pygame", "Game development and audio unavailable"))
    
    # Test numpy
    try:
        import numpy
        tests.append(("✅ NumPy", "Numerical computing available"))
    except ImportError:
        tests.append(("❌ NumPy", "Numerical computing unavailable"))
    
    # Test pandas
    try:
        import pandas
        tests.append(("✅ Pandas", "Data analysis available"))
    except ImportError:
        tests.append(("❌ Pandas", "Data analysis unavailable"))
    
    # Test scikit-learn
    try:
        import sklearn
        tests.append(("✅ Scikit-learn", "Machine learning available"))
    except ImportError:
        tests.append(("❌ Scikit-learn", "Machine learning unavailable"))
    
    # Test tkinter (usually built-in)
    try:
        import tkinter
        tests.append(("✅ Tkinter", "GUI framework available"))
    except ImportError:
        tests.append(("❌ Tkinter", "GUI framework unavailable"))
    
    # Test turtle (usually built-in)
    try:
        import turtle
        tests.append(("✅ Turtle", "Graphics library available"))
    except ImportError:
        tests.append(("❌ Turtle", "Graphics library unavailable"))
    
    # Print results
    for status, description in tests:
        print(f"{status:15} | {description}")
    
    success_count = sum(1 for status, _ in tests if status.startswith("✅"))
    total_count = len(tests)
    
    print("\n" + "=" * 40)
    print(f"📊 Results: {success_count}/{total_count} dependencies available")
    
    if success_count >= 5:  # At least basic functionality should work
        print("🎉 Time_Warp has sufficient dependencies to run!")
        return True
    else:
        print("⚠️  Some important dependencies are missing")
        return False

def test_james_import():
    """Test that Time_Warp core modules can be imported"""
    print("\n🔧 Testing Time_Warp Core Modules")
    print("=" * 40)
    
    try:
        # Add the project root to path
        project_root = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, project_root)
        
        from core.interpreter import Time_WarpInterpreter
        print("✅ Time_Warp Interpreter | Core interpreter module loaded")
        
        from core.languages import PilotExecutor, BasicExecutor, LogoExecutor
        print("✅ Language Executors | All language modules loaded")
        
        print("\n🎉 All Time_Warp core modules imported successfully!")
        return True
        
    except ImportError as e:
        print(f"❌ Time_Warp Import Error: {e}")
        print("⚠️  Check that Time_Warp files are in the correct location")
        return False

def main():
    """Run all tests"""
    deps_ok = test_imports()
    james_ok = test_james_import()
    
    print("\n" + "=" * 50)
    if deps_ok and james_ok:
        print("🚀 Time_Warp is ready to use!")
        print("\nTo start Time_Warp IDE, run:")
        print("  python Time_Warp.py")
        return 0
    else:
        print("❌ Some issues were found")
        print("\nTo install missing dependencies, run:")
        print("  python install_dependencies.py")
        return 1

if __name__ == "__main__":
    sys.exit(main())