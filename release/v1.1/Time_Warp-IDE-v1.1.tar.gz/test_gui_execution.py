#!/usr/bin/env python3
"""
Test GUI execution integration
"""

import tkinter as tk
from tkinter import scrolledtext
import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_gui_execution():
    """Test that GUI execution works properly"""
    print("Testing GUI execution integration...")
    
    root = tk.Tk()
    root.title("Test GUI Execution")
    root.geometry("600x400")
    
    # Create output widget similar to main GUI
    output_text = scrolledtext.ScrolledText(
        root,
        state=tk.DISABLED,
        wrap=tk.WORD,
        font=('Consolas', 10)
    )
    output_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    # Import and setup interpreter
    from core.interpreter import Time_WarpInterpreter
    
    # Custom output handler like in the main GUI
    class OutputHandler:
        def __init__(self, output_widget):
            self.output_widget = output_widget
        
        def insert(self, position, text):
            self.output_widget.config(state=tk.NORMAL)
            self.output_widget.insert(tk.END, text)
            self.output_widget.see(tk.END)
            self.output_widget.config(state=tk.DISABLED)
        
        def see(self, position):
            pass
    
    interpreter = Time_WarpInterpreter()
    interpreter.output_widget = OutputHandler(output_text)
    
    # Test programs
    test_programs = [
        ("BASIC", '''10 PRINT "Hello from BASIC!"
20 LET X = 42
30 PRINT "The answer is "; X
40 END'''),
        ("PILOT", '''T:Hello from PILOT!
A:NAME,"World"
T:Hello #NAME!'''),
        ("Logo", '''FORWARD 50
RIGHT 90
FORWARD 50''')
    ]
    
    def run_test(index=0):
        if index < len(test_programs):
            lang, program = test_programs[index]
            
            # Add separator
            output_text.config(state=tk.NORMAL)
            output_text.insert(tk.END, f"\n=== Testing {lang} ===\n")
            output_text.config(state=tk.DISABLED)
            
            # Run program
            try:
                result = interpreter.run_program(program, language=lang.lower())
                status = "✅ Success" if result else "❌ Failed"
                
                output_text.config(state=tk.NORMAL)
                output_text.insert(tk.END, f"{status}\n\n")
                output_text.config(state=tk.DISABLED)
                
            except Exception as e:
                output_text.config(state=tk.NORMAL)
                output_text.insert(tk.END, f"❌ Error: {e}\n\n")
                output_text.config(state=tk.DISABLED)
            
            # Schedule next test
            root.after(2000, lambda: run_test(index + 1))
        else:
            output_text.config(state=tk.NORMAL)
            output_text.insert(tk.END, "🎉 All tests completed!\n")
            output_text.config(state=tk.DISABLED)
    
    # Start testing after a brief delay
    root.after(1000, run_test)
    
    # Run for 10 seconds then close
    root.after(10000, root.quit)
    root.mainloop()
    root.destroy()
    
    print("GUI execution test completed!")

if __name__ == "__main__":
    test_gui_execution()