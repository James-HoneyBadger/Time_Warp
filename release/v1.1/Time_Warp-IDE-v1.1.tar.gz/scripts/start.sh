#!/bin/bash
# Simple Time_Warp IDE Launcher
echo "🚀 Starting Time_Warp IDE 1.1..."
python3 Time_Warp.py