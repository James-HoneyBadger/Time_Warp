#!/usr/bin/env python3
"""
Focused debugging test for Time_Warp IDE execution issues
"""

import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_individual_languages():
    """Test each language individually to identify issues"""
    print("🔍 Focused Language Testing")
    print("=" * 50)
    
    try:
        from core.interpreter import Time_WarpInterpreter
        interpreter = Time_WarpInterpreter()
        
        # Test 1: BASIC with explicit language setting
        print("\n🔵 Testing BASIC Language")
        basic_program = '''10 PRINT "Hello from BASIC!"
20 LET X = 42
30 PRINT "X = "; X
40 END'''
        
        print("Program:")
        print(basic_program)
        print("\nExecution:")
        
        result = interpreter.run_program(basic_program, language='basic')
        print(f"Result: {result}")
        print(f"Current language mode: {getattr(interpreter, 'current_language_mode', 'Not set')}")
        
        # Test 2: PILOT with explicit language setting
        print("\n🟢 Testing PILOT Language")
        pilot_program = '''T:Hello from PILOT!
A:NAME,World
T:Hello #NAME!'''
        
        print("Program:")
        print(pilot_program)
        print("\nExecution:")
        
        result = interpreter.run_program(pilot_program, language='pilot')
        print(f"Result: {result}")
        
        # Test 3: Logo with explicit language setting
        print("\n🟡 Testing LOGO Language")
        logo_program = '''FORWARD 50
RIGHT 90
FORWARD 50'''
        
        print("Program:")
        print(logo_program)
        print("\nExecution:")
        
        result = interpreter.run_program(logo_program, language='logo')
        print(f"Result: {result}")
        
        # Test 4: Python with explicit language setting
        print("\n🔴 Testing PYTHON Language")
        python_program = '''print("Hello from Python!")
x = 42
print(f"x = {x}")'''
        
        print("Program:")
        print(python_program)
        print("\nExecution:")
        
        result = interpreter.run_program(python_program, language='python')
        print(f"Result: {result}")
        
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()

def test_language_detection():
    """Test the language detection system"""
    print("\n🔍 Testing Language Detection")
    print("=" * 50)
    
    try:
        from core.interpreter import Time_WarpInterpreter
        interpreter = Time_WarpInterpreter()
        
        test_commands = [
            ("10 PRINT \"Hello\"", "Should be BASIC"),
            ("T:Hello World", "Should be PILOT"),
            ("FORWARD 50", "Should be LOGO"),
            ("print('Hello')", "Should be Python"),
            ("A:X,5", "Should be PILOT"),
            ("LET X = 10", "Should be BASIC"),
            ("RIGHT 90", "Should be LOGO"),
        ]
        
        for command, expected in test_commands:
            detected = interpreter.determine_command_type(command)
            print(f"Command: '{command}' -> Detected: {detected} ({expected})")
            
    except Exception as e:
        print(f"❌ Error during language detection test: {e}")
        import traceback
        traceback.print_exc()

def test_basic_executor_directly():
    """Test the BASIC executor directly"""
    print("\n🔵 Testing BASIC Executor Directly")
    print("=" * 50)
    
    try:
        from core.interpreter import Time_WarpInterpreter
        from core.languages.basic import BasicExecutor
        
        interpreter = Time_WarpInterpreter()
        basic_executor = BasicExecutor(interpreter)
        
        # Test individual commands
        commands = [
            'PRINT "Hello World!"',
            'LET X = 42',
            'PRINT "X = "; X',
        ]
        
        for cmd in commands:
            print(f"Executing: {cmd}")
            try:
                result = basic_executor.execute_command(cmd)
                print(f"Result: {result}")
            except Exception as e:
                print(f"Error: {e}")
            print()
            
    except Exception as e:
        print(f"❌ Error during direct executor test: {e}")
        import traceback
        traceback.print_exc()

def main():
    """Main test function"""
    print("🚀 Time_Warp IDE - Focused Debugging Test")
    print("=" * 60)
    
    # Run individual tests
    test_individual_languages()
    test_language_detection()
    test_basic_executor_directly()
    
    print("\n✅ Focused debugging test completed!")

if __name__ == "__main__":
    main()