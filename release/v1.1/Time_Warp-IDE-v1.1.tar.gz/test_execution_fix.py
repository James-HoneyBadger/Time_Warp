#!/usr/bin/env python3
"""
Test script to verify Time_Warp IDE execution works properly
"""

import tkinter as tk
import sys
import os

# Add the project directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Test basic execution
def test_basic_execution():
    print("Testing BASIC program execution...")
    
    # Create a minimal tkinter window for testing
    root = tk.Tk()
    root.withdraw()  # Hide the window
    
    try:
        from core.interpreter import Time_WarpInterpreter
        
        # Create a text widget for output
        output_widget = tk.Text(root)
        
        # Initialize interpreter with output widget
        interpreter = Time_WarpInterpreter(output_widget=output_widget)
        
        # Test BASIC program
        basic_program = '''
10 PRINT "Hello from BASIC!"
20 LET X = 5
30 PRINT "X equals "; X
40 FOR I = 1 TO 3
50 PRINT "Count: "; I
60 NEXT I
70 END
'''
        
        print("Running BASIC program...")
        result = interpreter.run_program(basic_program, language='basic')
        
        # Get output from the widget
        output = output_widget.get('1.0', tk.END).strip()
        print("Program output:")
        print(output)
        print(f"Execution result: {result}")
        
        # Test PILOT program
        pilot_program = '''
T:Hello from PILOT!
A:X,5
T:X equals #X
'''
        
        print("\nRunning PILOT program...")
        output_widget.delete('1.0', tk.END)  # Clear previous output
        result = interpreter.run_program(pilot_program, language='pilot')
        
        output = output_widget.get('1.0', tk.END).strip()
        print("Program output:")
        print(output)
        print(f"Execution result: {result}")
        
    except Exception as e:
        print(f"Error during testing: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        root.destroy()

if __name__ == "__main__":
    test_basic_execution()