#!/usr/bin/env python3
"""Test Galaga game graphics directly through interpreter"""

from core.interpreter import TimeWarpInterpreter

def run_galaga():
    interp = TimeWarpInterpreter()
    
    # Load and execute the Galaga program
    print("Loading Galaga game...")
    try:
        with open('galaga_game.timewarp', 'r') as f:
            lines = f.readlines()
        
        print(f"Loaded {len(lines)} lines")
        print("Executing program...")
        
        # Set up automatic input for INPUT statements
        interp.variables['DUMMY$'] = "START"
        
        # Execute each line
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if line and not line.startswith('REM'):
                print(f"Line {i}: {line}")
                
                # Skip INPUT statements for automatic execution
                if 'INPUT' in line.upper():
                    print("  (skipping INPUT - using automatic value)")
                    continue
                    
                result = interp.execute_line(line)
                if result == "error":
                    print(f"ERROR on line {i}: {line}")
                    break
                elif result == "exit":
                    print("Program ended")
                    break
                    
                # Stop after a reasonable number of lines to test graphics
                if i > 100:  # Stop after graphics initialization
                    print("Stopping after graphics initialization for testing...")
                    break
                    
    except Exception as e:
        print(f"Error: {e}")
    
    print("Program execution complete")

if __name__ == "__main__":
    run_galaga()