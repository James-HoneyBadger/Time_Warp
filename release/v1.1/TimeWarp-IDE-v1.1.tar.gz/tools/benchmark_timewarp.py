#!/usr/bin/env python3
"""
TimeWarp IDE Comprehensive Benchmark Suite
==========================================

Performance testing suite for TimeWarp IDE covering:
- Core interpreter performance
- Language execution speed
- Memory usage analysis
- Startup time measurements
- Theme switching performance
- File operations benchmarks
- Graphics rendering performance
"""

import time
import sys
import os
import gc
import tracemalloc
import threading
import subprocess
from datetime import datetime
from pathlib import Path

# Add TimeWarp to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class TimeWarpBenchmark:
    """Comprehensive benchmark suite for TimeWarp IDE"""
    
    def __init__(self):
        self.results = {}
        self.start_time = time.time()
        print("🚀 TimeWarp IDE Benchmark Suite")
        print("=" * 60)
        print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Python version: {sys.version}")
        print(f"Platform: {sys.platform}")
        print("-" * 60)
    
    def measure_time(self, func, *args, **kwargs):
        """Measure execution time of a function"""
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        return result, end - start
    
    def measure_memory(self, func, *args, **kwargs):
        """Measure memory usage of a function"""
        tracemalloc.start()
        gc.collect()
        
        start_memory = tracemalloc.get_traced_memory()[0]
        result = func(*args, **kwargs)
        end_memory = tracemalloc.get_traced_memory()[0]
        
        tracemalloc.stop()
        memory_used = end_memory - start_memory
        return result, memory_used
    
    def benchmark_startup_time(self):
        """Benchmark TimeWarp IDE startup time"""
        print("\n📊 Benchmarking Startup Performance...")
        
        try:
            # Import core components and measure time
            start = time.perf_counter()
            
            # Core interpreter import
            from core.interpreter import TimeWarpInterpreter
            interpreter_time = time.perf_counter() - start
            
            # Theme system import
            theme_start = time.perf_counter()
            from tools.theme import ThemeManager
            theme_time = time.perf_counter() - theme_start
            
            # Plugin system import
            plugin_start = time.perf_counter()  
            from plugins import PluginManager
            plugin_time = time.perf_counter() - plugin_start
            
            total_import_time = time.perf_counter() - start
            
            # Test interpreter initialization
            init_start = time.perf_counter()
            interpreter = TimeWarpInterpreter()
            init_time = time.perf_counter() - init_start
            
            self.results['startup'] = {
                'interpreter_import': interpreter_time * 1000,
                'theme_import': theme_time * 1000,
                'plugin_import': plugin_time * 1000,
                'total_import': total_import_time * 1000,
                'interpreter_init': init_time * 1000,
                'total_startup': (total_import_time + init_time) * 1000
            }
            
            print(f"  ✅ Interpreter import: {interpreter_time*1000:.2f}ms")
            print(f"  ✅ Theme system import: {theme_time*1000:.2f}ms")
            print(f"  ✅ Plugin system import: {plugin_time*1000:.2f}ms")
            print(f"  ✅ Total imports: {total_import_time*1000:.2f}ms")
            print(f"  ✅ Interpreter init: {init_time*1000:.2f}ms")
            print(f"  🎯 Total startup: {(total_import_time + init_time)*1000:.2f}ms")
            
            return interpreter
            
        except Exception as e:
            print(f"  ❌ Startup benchmark failed: {e}")
            self.results['startup'] = {'error': str(e)}
            return None
    
    def benchmark_language_execution(self, interpreter):
        """Benchmark language execution performance"""
        print("\n📊 Benchmarking Language Execution...")
        
        if not interpreter:
            print("  ❌ Skipping - no interpreter available")
            return
        
        # PILOT language benchmarks
        pilot_tests = [
            ("Simple output", "T:Hello World\nEND"),
            ("Variable operations", "U:X=100\nU:Y=200\nC:RESULT=*X*+*Y*\nT:Result: *RESULT*\nEND"),
            ("Loop operations", "U:I=1\nL:LOOP\nT:Count: *I*\nC:I=*I*+1\nY:*I* <= 10\nJ:LOOP\nEND"),
            ("String manipulation", "U:NAME=TimeWarp\nU:MSG=Hello *NAME* IDE\nT:*MSG*\nEND")
        ]
        
        pilot_results = {}
        for test_name, code in pilot_tests:
            try:
                _, exec_time = self.measure_time(interpreter.run_program, code)
                pilot_results[test_name] = exec_time * 1000
                print(f"  ✅ PILOT {test_name}: {exec_time*1000:.2f}ms")
            except Exception as e:
                pilot_results[test_name] = f"Error: {e}"
                print(f"  ❌ PILOT {test_name}: Failed - {e}")
        
        # BASIC language benchmarks
        basic_tests = [
            ("Simple output", '10 PRINT "Hello World"\n20 END'),
            ("Variables", '10 LET X = 42\n20 PRINT "Value: "; X\n30 END'),
            ("Math operations", '10 LET A = 10\n20 LET B = 5\n30 LET C = A * B + A / B\n40 PRINT C\n50 END'),
            ("For loop", '10 FOR I = 1 TO 5\n20 PRINT "Iteration: "; I\n30 NEXT I\n40 END')
        ]
        
        basic_results = {}
        for test_name, code in basic_tests:
            try:
                _, exec_time = self.measure_time(interpreter.run_program, code)
                basic_results[test_name] = exec_time * 1000
                print(f"  ✅ BASIC {test_name}: {exec_time*1000:.2f}ms")
            except Exception as e:
                basic_results[test_name] = f"Error: {e}"
                print(f"  ❌ BASIC {test_name}: Failed - {e}")
        
        # Logo language benchmarks
        logo_tests = [
            ("Simple movement", "FORWARD 50\nRIGHT 90\nFORWARD 30"),
            ("Square drawing", "REPEAT 4 [FORWARD 50 RIGHT 90]"),
            ("Nested commands", "REPEAT 8 [FORWARD 40 RIGHT 45]"),
            ("Complex pattern", "REPEAT 12 [FORWARD 60 RIGHT 30 FORWARD 20 LEFT 60]")
        ]
        
        logo_results = {}
        for test_name, code in logo_tests:
            try:
                _, exec_time = self.measure_time(interpreter.run_program, code)
                logo_results[test_name] = exec_time * 1000
                print(f"  ✅ Logo {test_name}: {exec_time*1000:.2f}ms")
            except Exception as e:
                logo_results[test_name] = f"Error: {e}"
                print(f"  ❌ Logo {test_name}: Failed - {e}")
        
        self.results['language_execution'] = {
            'pilot': pilot_results,
            'basic': basic_results,
            'logo': logo_results
        }
    
    def benchmark_memory_usage(self, interpreter):
        """Benchmark memory usage"""
        print("\n📊 Benchmarking Memory Usage...")
        
        if not interpreter:
            print("  ❌ Skipping - no interpreter available")
            return
        
        try:
            # Measure baseline memory
            gc.collect()
            tracemalloc.start()
            
            baseline = tracemalloc.get_traced_memory()[0]
            
            # Execute various programs and measure memory
            programs = [
                ("Empty program", "END"),
                ("Variable storage", "U:X=100\nU:Y=200\nU:Z=300\nEND"),
                ("Large loop", "U:I=1\nL:LOOP\nC:I=*I*+1\nY:*I* <= 1000\nJ:LOOP\nEND")
            ]
            
            memory_results = {}
            for test_name, code in programs:
                gc.collect()
                start_mem = tracemalloc.get_traced_memory()[0]
                
                interpreter.run_program(code)
                
                end_mem = tracemalloc.get_traced_memory()[0]
                memory_used = end_mem - start_mem
                
                memory_results[test_name] = memory_used / 1024  # Convert to KB
                print(f"  ✅ {test_name}: {memory_used/1024:.2f} KB")
            
            tracemalloc.stop()
            
            self.results['memory_usage'] = memory_results
            
        except Exception as e:
            print(f"  ❌ Memory benchmark failed: {e}")
            self.results['memory_usage'] = {'error': str(e)}
    
    def benchmark_theme_performance(self):
        """Benchmark theme switching performance"""
        print("\n📊 Benchmarking Theme Performance...")
        
        try:
            from tools.theme import ThemeManager, get_theme_colors
            
            theme_names = ['dracula', 'monokai', 'solarized_dark', 'ocean',
                          'spring', 'sunset', 'candy', 'forest']
            
            theme_results = {}
            
            for theme_name in theme_names:
                start = time.perf_counter()
                colors = get_theme_colors(theme_name)
                end = time.perf_counter()
                
                theme_time = (end - start) * 1000
                theme_results[theme_name] = theme_time
                print(f"  ✅ {theme_name.title()} theme: {theme_time:.2f}ms")
            
            # Test theme manager initialization
            start = time.perf_counter()
            theme_manager = ThemeManager()
            init_time = (time.perf_counter() - start) * 1000
            
            theme_results['theme_manager_init'] = init_time
            print(f"  ✅ ThemeManager init: {init_time:.2f}ms")
            
            self.results['theme_performance'] = theme_results
            
        except Exception as e:
            print(f"  ❌ Theme benchmark failed: {e}")
            self.results['theme_performance'] = {'error': str(e)}
    
    def benchmark_file_operations(self):
        """Benchmark file I/O operations"""
        print("\n📊 Benchmarking File Operations...")
        
        try:
            test_dir = Path("benchmark_temp")
            test_dir.mkdir(exist_ok=True)
            
            # Test program files
            test_programs = {
                'simple.timewarp': 'T:Hello World\nEND',
                'complex.pilot': 'U:NAME=User\nT:Welcome *NAME*\nU:COUNT=5\nL:LOOP\nT:Count: *COUNT*\nC:COUNT=*COUNT*-1\nY:*COUNT* > 0\nJ:LOOP\nEND',
                'basic.bas': '10 PRINT "TimeWarp BASIC"\n20 FOR I = 1 TO 10\n30 PRINT I\n40 NEXT I\n50 END',
                'logo.logo': 'REPEAT 8 [FORWARD 50 RIGHT 45]'
            }
            
            file_results = {}
            
            # Write performance
            for filename, content in test_programs.items():
                filepath = test_dir / filename
                
                start = time.perf_counter()
                filepath.write_text(content)
                write_time = (time.perf_counter() - start) * 1000
                
                file_results[f'{filename}_write'] = write_time
                print(f"  ✅ Write {filename}: {write_time:.2f}ms")
            
            # Read performance
            for filename in test_programs.keys():
                filepath = test_dir / filename
                
                start = time.perf_counter()
                content = filepath.read_text()
                read_time = (time.perf_counter() - start) * 1000
                
                file_results[f'{filename}_read'] = read_time
                print(f"  ✅ Read {filename}: {read_time:.2f}ms")
            
            # Cleanup
            for filepath in test_dir.glob("*"):
                filepath.unlink()
            test_dir.rmdir()
            
            self.results['file_operations'] = file_results
            
        except Exception as e:
            print(f"  ❌ File operations benchmark failed: {e}")
            self.results['file_operations'] = {'error': str(e)}
    
    def benchmark_concurrent_execution(self, interpreter):
        """Benchmark concurrent program execution"""
        print("\n📊 Benchmarking Concurrent Execution...")
        
        if not interpreter:
            print("  ❌ Skipping - no interpreter available")
            return
        
        try:
            def run_program(code, results, index):
                start = time.perf_counter()
                interpreter.run_program(code)
                end = time.perf_counter()
                results[index] = (end - start) * 1000
            
            # Test programs for concurrent execution
            programs = [
                "U:X=1\nL:LOOP\nC:X=*X*+1\nY:*X* <= 100\nJ:LOOP\nEND",
                "T:Program 2 running\nU:I=1\nL:COUNT\nC:I=*I*+1\nY:*I* <= 50\nJ:COUNT\nEND",
                "REPEAT 20 [FORWARD 10 RIGHT 18]",
                '10 FOR I = 1 TO 25\n20 LET X = I * I\n30 NEXT I\n40 END'
            ]
            
            # Sequential execution
            sequential_start = time.perf_counter()
            for i, program in enumerate(programs):
                interpreter.run_program(program)
            sequential_time = (time.perf_counter() - sequential_start) * 1000
            
            print(f"  ✅ Sequential execution: {sequential_time:.2f}ms")
            
            # Note: True concurrent execution with threading would require
            # thread-safe interpreter design. For now, we measure sequential.
            
            self.results['concurrent_execution'] = {
                'sequential_time': sequential_time,
                'programs_count': len(programs),
                'average_per_program': sequential_time / len(programs)
            }
            
        except Exception as e:
            print(f"  ❌ Concurrent execution benchmark failed: {e}")
            self.results['concurrent_execution'] = {'error': str(e)}
    
    def generate_report(self):
        """Generate comprehensive benchmark report"""
        total_time = time.time() - self.start_time
        
        print("\n" + "=" * 60)
        print("📋 TIMEWARP IDE BENCHMARK REPORT")
        print("=" * 60)
        print(f"Total benchmark time: {total_time:.2f} seconds")
        print(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Performance summary
        if 'startup' in self.results and 'total_startup' in self.results['startup']:
            startup_time = self.results['startup']['total_startup']
            print(f"\n🚀 STARTUP PERFORMANCE")
            print(f"   Total startup time: {startup_time:.2f}ms")
            
            if startup_time < 500:
                print("   ⚡ Excellent startup performance!")
            elif startup_time < 1000:
                print("   ✅ Good startup performance")
            elif startup_time < 2000:
                print("   ⚠️  Moderate startup performance")
            else:
                print("   🐌 Slow startup - consider optimization")
        
        # Language performance summary
        if 'language_execution' in self.results:
            print(f"\n💻 LANGUAGE EXECUTION PERFORMANCE")
            for lang, tests in self.results['language_execution'].items():
                if isinstance(tests, dict):
                    avg_time = sum(t for t in tests.values() if isinstance(t, (int, float))) / len(tests)
                    print(f"   {lang.upper()} average: {avg_time:.2f}ms")
        
        # Memory usage summary  
        if 'memory_usage' in self.results:
            print(f"\n🧠 MEMORY USAGE")
            total_memory = sum(m for m in self.results['memory_usage'].values() if isinstance(m, (int, float)))
            print(f"   Total memory used: {total_memory:.2f} KB")
        
        # Overall rating
        print(f"\n⭐ OVERALL PERFORMANCE RATING")
        
        score = 100
        if 'startup' in self.results:
            startup_time = self.results['startup'].get('total_startup', 1000)
            if startup_time > 2000:
                score -= 20
            elif startup_time > 1000:
                score -= 10
        
        if score >= 90:
            print("   🌟 Excellent (A+)")
        elif score >= 80:
            print("   ⭐ Very Good (A)")
        elif score >= 70:
            print("   ✅ Good (B)")
        elif score >= 60:
            print("   ⚠️  Fair (C)")
        else:
            print("   🔧 Needs Optimization (D)")
        
        print("\n" + "=" * 60)
        print("Benchmark completed successfully! 🎉")
        
        return self.results

def main():
    """Run the complete TimeWarp IDE benchmark suite"""
    benchmark = TimeWarpBenchmark()
    
    # Run all benchmarks
    interpreter = benchmark.benchmark_startup_time()
    benchmark.benchmark_language_execution(interpreter)
    benchmark.benchmark_memory_usage(interpreter)
    benchmark.benchmark_theme_performance()
    benchmark.benchmark_file_operations()
    benchmark.benchmark_concurrent_execution(interpreter)
    
    # Generate final report
    results = benchmark.generate_report()
    
    # Save results to file
    try:
        import json
        with open('benchmark_results.json', 'w') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"\n💾 Results saved to benchmark_results.json")
    except Exception as e:
        print(f"\n❌ Failed to save results: {e}")

if __name__ == "__main__":
    main()