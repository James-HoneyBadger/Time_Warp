#!/usr/bin/env python3
"""
Test script for Learning Assistant Plugin
Tests the plugin functionality and UI components
"""

import sys
import os
import tkinter as tk
from tkinter import ttk

# Add the project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

# Import the plugin
from tools.plugins.learning_assistant.plugin import LearningAssistantPlugin


def test_plugin_basic():
    """Test basic plugin functionality"""
    print("🔧 Testing Learning Assistant Plugin...")
    
    # Create plugin instance
    plugin = LearningAssistantPlugin()
    
    # Test basic properties
    assert plugin.name == "Learning Assistant"
    assert plugin.version == "1.0.0"
    assert "educational" in plugin.description.lower()
    
    # Test components initialization
    assert plugin.code_analyzer is not None
    assert plugin.tutorial_manager is not None
    assert hasattr(plugin, 'learning_paths')
    assert hasattr(plugin, 'user_progress')
    
    print("✅ Basic plugin tests passed")


def test_code_analyzer():
    """Test code analysis functionality"""
    print("🔍 Testing Code Analyzer...")
    
    plugin = LearningAssistantPlugin()
    analyzer = plugin.code_analyzer
    
    # Test PILOT code analysis
    pilot_code = """
    R: This is a simple PILOT program
    T: Hello, World!
    A: #NAME
    T: Nice to meet you, #NAME!
    E:
    """
    
    result = analyzer.analyze_code(pilot_code, 'pilot')
    assert 'score' in result
    assert 'quality' in result
    assert 'suggestions' in result
    assert result['score'] >= 0
    
    # Test BASIC code analysis
    basic_code = """
    10 REM Simple BASIC program
    20 PRINT "Hello, World!"
    30 INPUT "Enter your name: "; N$
    40 PRINT "Hello, "; N$
    50 END
    """
    
    result = analyzer.analyze_code(basic_code, 'basic')
    assert result['score'] > 0
    
    print("✅ Code analyzer tests passed")


def test_tutorial_manager():
    """Test tutorial management"""
    print("📚 Testing Tutorial Manager...")
    
    plugin = LearningAssistantPlugin()
    tutorial_mgr = plugin.tutorial_manager
    
    # Test tutorial loading
    assert len(tutorial_mgr.tutorials) > 0
    
    # Test getting tutorials by language
    pilot_tutorials = tutorial_mgr.get_tutorials_for_language('pilot')
    basic_tutorials = tutorial_mgr.get_tutorials_for_language('basic')
    logo_tutorials = tutorial_mgr.get_tutorials_for_language('logo')
    
    assert len(pilot_tutorials) > 0
    assert len(basic_tutorials) > 0
    assert len(logo_tutorials) > 0
    
    # Test getting specific tutorial
    first_tutorial_id = list(tutorial_mgr.tutorials.keys())[0]
    tutorial = tutorial_mgr.get_tutorial(first_tutorial_id)
    assert tutorial is not None
    assert 'title' in tutorial
    assert 'steps' in tutorial
    
    print("✅ Tutorial manager tests passed")


def test_learning_paths():
    """Test learning path functionality"""
    print("🛤️ Testing Learning Paths...")
    
    plugin = LearningAssistantPlugin()
    
    # Create default learning paths
    plugin.create_default_learning_paths()
    
    assert len(plugin.learning_paths) > 0
    
    # Test path properties
    for path_id, path in plugin.learning_paths.items():
        assert hasattr(path, 'name')
        assert hasattr(path, 'description')
        assert hasattr(path, 'lessons')
        assert len(path.lessons) > 0
    
    print("✅ Learning paths tests passed")


def test_plugin_ui():
    """Test plugin UI creation (basic test)"""
    print("🖼️ Testing Plugin UI...")
    
    # Create root window
    root = tk.Tk()
    root.title("Test Learning Assistant")
    root.geometry("800x600")
    
    try:
        # Create plugin with parent
        plugin = LearningAssistantPlugin()
        plugin.parent = root
        
        # Test initialization
        result = plugin.initialize(root)
        assert result == True
        
        # Test activation (creates UI)
        result = plugin.activate()
        assert result == True
        
        # Verify UI components exist
        assert plugin.main_window is not None
        assert plugin.notebook is not None
        
        print("✅ Plugin UI tests passed")
        
        # Show for a moment (comment out for automated testing)
        # root.update()
        # root.after(2000, root.quit)  # Close after 2 seconds
        # root.mainloop()
        
    finally:
        # Clean up
        plugin.destroy()
        root.destroy()


def test_plugin_integration():
    """Test plugin integration features"""
    print("🔗 Testing Plugin Integration...")
    
    plugin = LearningAssistantPlugin()
    
    # Test data persistence methods
    try:
        plugin._save_user_data()
        plugin._load_user_data()
        print("✅ Data persistence working")
    except Exception as e:
        print(f"⚠️ Data persistence issue: {e}")
    
    # Test plugin lifecycle
    assert plugin.initialize() == True
    assert plugin.activate() == True
    assert plugin.deactivate() == True
    assert plugin.destroy() == True
    
    print("✅ Plugin integration tests passed")


def run_comprehensive_test():
    """Run all tests"""
    print("🎓 Learning Assistant Plugin - Comprehensive Test")
    print("=" * 50)
    
    try:
        test_plugin_basic()
        test_code_analyzer()
        test_tutorial_manager()
        test_learning_paths()
        test_plugin_integration()
        test_plugin_ui()
        
        print("\n🎉 All Learning Assistant Plugin tests passed!")
        print("✅ Plugin is ready for integration with TimeWarp IDE")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = run_comprehensive_test()
    sys.exit(0 if success else 1)