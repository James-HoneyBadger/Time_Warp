#!/usr/bin/env python3
"""
BASIC Interpreter Edge Case Testing
==================================

This script tests various edge cases and boundary conditions in the BASIC interpreter
to identify potential issues that could cause serious problems in educational programs.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import TimeWarpInterpreter

def test_basic_edge_cases():
    """Test BASIC interpreter edge cases"""
    print("🔧 Testing BASIC Interpreter Edge Cases...")
    
    test_cases = [
        {
            "name": "Variable Name Edge Cases",
            "program": """
10 LET A = 5
20 LET AA = 10
30 LET A1 = 15
40 LET A$ = "test"
50 PRINT A, AA, A1, A$
60 END
"""
        },
        {
            "name": "Expression Edge Cases", 
            "program": """
10 LET X = 5 + 3 * 2
20 LET Y = (5 + 3) * 2
30 LET Z = 10 / 3
40 LET W = 10 MOD 3
50 PRINT X, Y, Z, W
60 END
"""
        },
        {
            "name": "FOR Loop Boundary Cases",
            "program": """
10 FOR I = 1 TO 1
20   PRINT "Single iteration:", I
30 NEXT I
40 FOR J = 5 TO 1 STEP -1
50   PRINT "Reverse:", J
60 NEXT J
70 FOR K = 1 TO 10 STEP 3
80   PRINT "Step 3:", K
90 NEXT K
100 END
"""
        },
        {
            "name": "Nested Loop Edge Cases",
            "program": """
10 FOR I = 1 TO 2
20   FOR J = 1 TO 2
30     PRINT "I="; I; " J="; J
40   NEXT J
50 NEXT I
60 END
"""
        },
        {
            "name": "GOSUB/RETURN Edge Cases",
            "program": """
10 GOSUB 100
20 PRINT "Back from subroutine"
30 END
100 PRINT "In subroutine"
110 GOSUB 200
120 RETURN
200 PRINT "Nested subroutine"
210 RETURN
"""
        },
        {
            "name": "IF/THEN Edge Cases",
            "program": """
10 LET X = 5
20 IF X = 5 THEN PRINT "X equals 5"
30 IF X <> 5 THEN PRINT "This should not print"
40 IF X > 0 THEN PRINT "X is positive"
50 IF X <= 10 THEN PRINT "X is <= 10"
60 END
"""
        },
        {
            "name": "String Handling Edge Cases",
            "program": """
10 LET A$ = "Hello"
20 LET B$ = "World"
30 LET C$ = A$ + " " + B$
40 PRINT C$
50 LET D$ = ""
60 PRINT "Empty string length test"
70 END
"""
        },
        {
            "name": "Zero and Negative Number Cases",
            "program": """
10 LET X = 0
20 LET Y = -5
30 LET Z = 10 / X
40 PRINT X, Y, Z
50 END
"""
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n--- Test {i}: {test_case['name']} ---")
        interpreter = TimeWarpInterpreter()
        
        try:
            print("Program:")
            for line in test_case['program'].strip().split('\n'):
                if line.strip():
                    print(f"  {line}")
            print("\nOutput:")
            interpreter.run_program(test_case['program'])
            print("✅ Test completed successfully")
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
        print("-" * 40)

if __name__ == "__main__":
    test_basic_edge_cases()