print("Hello from Python in TimeWarp IDE!")
name = "TimeWarp"
print(f"Welcome to {name} IDE with Python support")