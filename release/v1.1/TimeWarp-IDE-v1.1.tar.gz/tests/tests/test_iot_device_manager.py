#!/usr/bin/env python3
"""
Test the IoT Device Manager Plugin
"""

import sys
import os

# Add the current directory to Python path for imports
sys.path.append('/path/to/timewarp')
sys.path.append('/home/james/Time_Warp/tools/plugins/iot_device_manager')

# Test imports
try:
    from tools.plugins.iot_device_manager.plugin import IoTDeviceManagerPlugin
    print("✅ IoT Device Manager plugin imported successfully")
except ImportError as e:
    print(f"❌ Failed to import IoT Device Manager plugin: {e}")
    sys.exit(1)

# Test plugin creation
try:
    # Create a mock IDE instance
    class MockIDE:
        def __init__(self):
            self.title = "Mock TimeWarp IDE"
        
    # Create a mock framework
    class MockFramework:
        def __init__(self):
            self.event_manager = MockEventManager()
            self.registry = MockRegistry()
    
    class MockEventManager:
        def subscribe(self, event_name, callback):
            print(f"Event subscribed: {event_name}")
    
    class MockRegistry:
        def register(self, name, component):
            print(f"Component registered: {name}")
    
    # Test plugin instantiation
    mock_ide = MockIDE()
    mock_framework = MockFramework()
    
    plugin = IoTDeviceManagerPlugin(mock_ide, mock_framework)
    print("✅ IoT Device Manager plugin created successfully")
    
    # Test plugin metadata
    print(f"Plugin Name: {plugin.name}")
    print(f"Plugin Version: {plugin.version}")
    print(f"Plugin Author: {plugin.author}")
    print(f"Plugin Category: {plugin.category}")
    print(f"Plugin Description: {plugin.description}")
    
    # Test plugin initialization
    if plugin.initialize():
        print("✅ IoT Device Manager plugin initialized successfully")
    else:
        print("❌ IoT Device Manager plugin initialization failed")
    
    # Test plugin activation
    if plugin.activate():
        print("✅ IoT Device Manager plugin activated successfully")
    else:
        print("❌ IoT Device Manager plugin activation failed")
    
    # Test plugin deactivation
    if plugin.deactivate():
        print("✅ IoT Device Manager plugin deactivated successfully")
    else:
        print("❌ IoT Device Manager plugin deactivation failed")
    
    print("\n🎉 All IoT Device Manager plugin tests passed!")
    
except Exception as e:
    print(f"❌ Error testing IoT Device Manager plugin: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)