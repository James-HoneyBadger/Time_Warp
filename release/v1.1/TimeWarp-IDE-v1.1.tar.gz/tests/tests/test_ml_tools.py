#!/usr/bin/env python3
"""
Test script for the AI/ML tools extraction
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, '/path/to/timewarp')

try:
    # Test importing AI/ML components
    from tools.ml import AIMLIntegration, MLManagerDialog
    print("✓ Successfully imported AI/ML components")
    
    # Test creating AI/ML integration instance
    aiml = AIMLIntegration()
    print("✓ AIMLIntegration created")
    print(f"  - NumPy available: {aiml.numpy_available}")
    print(f"  - Pandas available: {aiml.pandas_available}")
    print(f"  - Scikit-learn available: {aiml.sklearn_available}")
    
    # Test basic functionality without dependencies
    aiml.log_ml_message("Test message logged successfully")
    print("✓ Basic logging functionality works")
    
    # Test model info retrieval
    info = aiml.get_model_info("nonexistent_model")
    assert info is None, "Expected None for nonexistent model"
    print("✓ Model info retrieval works")
    
    # Test clearing models
    aiml.clear_models()
    print("✓ Model clearing works")
    
    # Test creating mock IDE for dialog
    class MockIDE:
        def __init__(self):
            self.root = None
            self.interpreter = None
    
    mock_ide = MockIDE()
    dialog = MLManagerDialog(mock_ide)
    print("✓ MLManagerDialog created")
    
    print("\n🎉 All AI/ML component tests passed!")
    print("Note: Advanced ML features require numpy, pandas, and scikit-learn")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Error: {e}")
    sys.exit(1)