#!/usr/bin/perl
print "Hello from Perl in TimeWarp IDE!\n";
my $name = "TimeWarp";
print "Welcome to $name IDE with Perl support\n";