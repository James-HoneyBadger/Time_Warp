#!/usr/bin/env python3
"""
Comprehensive Test Suite for Enhanced TimeWarp IDE
Tests all major components and integrations
"""

import sys
import os
import importlib.util
import traceback

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Test all core imports"""
    print("🧪 Testing Core Imports...")
    
    try:
        # Test core editor imports
        from core.editor.language_engine import LanguageEngine
        from core.editor.code_formatter import CodeFormatter
        from core.editor.syntax_analyzer import SyntaxAnalyzer
        from core.editor.code_completion import CodeCompletionEngine
        from core.editor.compiler_manager import CompilerManager
        from core.editor.enhanced_editor import EnhancedCodeEditor
        print("  ✅ Core editor components imported successfully")
        
        # Test framework imports
        from core.framework import TimeWarpFramework
        from tools.tool_manager import ToolManager
        print("  ✅ Framework components imported successfully")
        
        # Test existing compilers
        try:
            import pilot_compiler
            print("  ✅ PILOT compiler available")
        except ImportError:
            print("  ⚠️ PILOT compiler not found")
        
        try:
            import basic_compiler
            print("  ✅ BASIC compiler available")
        except ImportError:
            print("  ⚠️ BASIC compiler not found")
            
        try:
            import logo_compiler
            print("  ✅ Logo compiler available")
        except ImportError:
            print("  ⚠️ Logo compiler not found")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Import error: {e}")
        traceback.print_exc()
        return False

def test_language_engines():
    """Test language engine functionality"""
    print("\n🧪 Testing Language Engines...")
    
    try:
        from core.editor.language_engine import LanguageEngine
        
        # Test engine creation
        engine = LanguageEngine()
        print("  ✅ LanguageEngine created successfully")
        
        # Test language switching
        for lang in ['pilot', 'basic', 'logo', 'python']:
            if engine.set_language(lang):
                print(f"  ✅ {lang.upper()} engine loaded")
                
                # Test basic functionality
                current_engine = engine.get_current_engine()
                if current_engine:
                    # Test completions
                    completions = current_engine.get_completions("", 0)
                    print(f"    - {len(completions)} completions available")
                    
                    # Test syntax checking
                    errors = current_engine.check_syntax("test code")
                    print(f"    - Syntax checker returned {len(errors)} results")
                    
                    # Test formatting
                    formatted = current_engine.format_code("test code")
                    print(f"    - Formatter processed text")
                else:
                    print(f"  ❌ {lang.upper()} engine not available")
            else:
                print(f"  ❌ Failed to load {lang.upper()} engine")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Language engine error: {e}")
        traceback.print_exc()
        return False

def test_compiler_integration():
    """Test compiler integration"""
    print("\n🧪 Testing Compiler Integration...")
    
    try:
        from core.editor.compiler_manager import CompilerManager
        
        manager = CompilerManager()
        print("  ✅ CompilerManager created successfully")
        
        # Test available compilers
        compilers = manager.get_available_compilers()
        print(f"  ✅ Available compilers: {', '.join(compilers)}")
        
        # Test compiler capabilities
        for lang in compilers:
            if manager.supports_language(lang):
                print(f"  ✅ {lang.upper()} compilation supported")
                
                # Test menu items
                menu_items = manager.get_compilation_menu_items()
                print(f"    - {len(menu_items)} menu items available")
            else:
                print(f"  ⚠️ {lang.upper()} compilation not supported")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Compiler integration error: {e}")
        traceback.print_exc()
        return False

def test_enhanced_editor():
    """Test enhanced editor functionality"""
    print("\n🧪 Testing Enhanced Editor...")
    
    try:
        import tkinter as tk
        from core.editor.enhanced_editor import EnhancedCodeEditor
        
        # Create minimal test window
        root = tk.Tk()
        root.withdraw()  # Hide window
        
        frame = tk.Frame(root)
        editor = EnhancedCodeEditor(frame, initial_language="pilot")
        print("  ✅ EnhancedCodeEditor created successfully")
        
        # Test language switching
        for lang in ['pilot', 'basic', 'logo', 'python']:
            editor.set_language(lang)
            current = editor.get_current_language()
            if current == lang:
                print(f"  ✅ Language switched to {lang.upper()}")
            else:
                print(f"  ❌ Language switch failed for {lang.upper()}")
        
        # Test content operations
        test_content = "T: Hello World!"
        editor.set_content(test_content)
        retrieved = editor.get_content()
        if test_content in retrieved:
            print("  ✅ Content set and retrieved successfully")
        else:
            print("  ❌ Content operation failed")
        
        # Test compilation menu
        menu_items = editor.get_compilation_menu_items()
        print(f"  ✅ {len(menu_items)} compilation menu items available")
        
        root.destroy()
        return True
        
    except Exception as e:
        print(f"  ❌ Enhanced editor error: {e}")
        traceback.print_exc()
        return False

def test_framework_integration():
    """Test framework integration"""
    print("\n🧪 Testing Framework Integration...")
    
    try:
        # Test if framework is available
        spec = importlib.util.find_spec("core.framework")
        if spec is not None:
            from core.framework import TimeWarpFramework
            print("  ✅ TimeWarpFramework available")
            
            # Test tool manager
            try:
                from tools.tool_manager import ToolManager
                print("  ✅ ToolManager available")
            except ImportError:
                print("  ⚠️ ToolManager not available")
        else:
            print("  ⚠️ Framework not found - running in standalone mode")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Framework integration error: {e}")
        traceback.print_exc()
        return False

def test_file_operations():
    """Test file operations and compatibility"""
    print("\n🧪 Testing File Operations...")
    
    try:
        import tempfile
        from core.editor.enhanced_editor import EnhancedCodeEditor
        import tkinter as tk
        
        # Create test environment
        root = tk.Tk()
        root.withdraw()
        frame = tk.Frame(root)
        editor = EnhancedCodeEditor(frame, initial_language="pilot")
        
        # Test file extensions and language detection
        test_files = {
            'test.pilot': 'pilot',
            'test.bas': 'basic', 
            'test.logo': 'logo',
            'test.py': 'python'
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            for filename, expected_lang in test_files.items():
                filepath = os.path.join(temp_dir, filename)
                with open(filepath, 'w') as f:
                    f.write(f"# Test file for {expected_lang}")
                
                if os.path.exists(filepath):
                    print(f"  ✅ Created test file: {filename}")
                else:
                    print(f"  ❌ Failed to create: {filename}")
        
        root.destroy()
        return True
        
    except Exception as e:
        print(f"  ❌ File operations error: {e}")
        traceback.print_exc()
        return False

def run_comprehensive_tests():
    """Run all tests and provide summary"""
    print("🚀 TimeWarp IDE Comprehensive Test Suite")
    print("=" * 50)
    
    test_results = []
    
    # Run all tests
    test_results.append(("Core Imports", test_imports()))
    test_results.append(("Language Engines", test_language_engines()))
    test_results.append(("Compiler Integration", test_compiler_integration()))
    test_results.append(("Enhanced Editor", test_enhanced_editor()))
    test_results.append(("Framework Integration", test_framework_integration()))
    test_results.append(("File Operations", test_file_operations()))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 TEST SUMMARY")
    print("=" * 50)
    
    passed = 0
    total = len(test_results)
    
    for test_name, result in test_results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:<25} {status}")
        if result:
            passed += 1
    
    print(f"\nResults: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! TimeWarp IDE is ready for use.")
    else:
        print("⚠️ Some tests failed. Check the output above for details.")
        
    return passed == total

if __name__ == "__main__":
    success = run_comprehensive_tests()
    sys.exit(0 if success else 1)