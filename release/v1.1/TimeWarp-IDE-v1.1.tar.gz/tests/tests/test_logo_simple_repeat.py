#!/usr/bin/env python3
"""
Simple Logo REPEAT test to debug the parsing issue
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import TimeWarpInterpreter

def test_simple_repeat():
    """Test simple REPEAT with single commands"""
    print("🔧 Testing Simple Logo REPEAT...")
    
    interpreter = TimeWarpInterpreter()
    
    # Test simple REPEAT with just movement
    logo_program = """
CLEARSCREEN
HOME
REPEAT 4 [ FORWARD 50 ]
HOME
"""
    
    print("Running Simple Logo REPEAT program:")
    print("--- OUTPUT ---")
    
    try:
        interpreter.run_program(logo_program)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("--- END OUTPUT ---\n")

if __name__ == "__main__":
    test_simple_repeat()