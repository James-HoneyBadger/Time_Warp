#!/usr/bin/env python3
"""
TimeWarp GUI Canvas Integration Test
================================

Test that TimeWarp IDE loads properly and canvases integrate correctly with the GUI.
"""

import sys
import os
sys.path.insert(0, '/path/to/timewarp')

def test_james_gui_import():
    """Test that TimeWarp GUI can be imported without errors"""
    try:
        from TimeWarp import TimeWarpII
        print("✅ TimeWarp GUI imports successfully")
        return True
    except Exception as e:
        print(f"❌ TimeWarp GUI import failed: {e}")
        return False

def test_james_initialization():
    """Test that TimeWarp IDE can be initialized"""
    try:
        # This will test the initialization without actually showing the GUI
        import tkinter as tk
        from TimeWarp import TimeWarpII
        
        # Create a hidden root window for testing
        root = tk.Tk()
        root.withdraw()  # Hide the window
        
        print("✅ TimeWarp IDE initialization components work")
        root.destroy()
        return True
    except Exception as e:
        print(f"❌ TimeWarp IDE initialization failed: {e}")
        return False

def test_interpreter_canvas_connection():
    """Test that the interpreter can connect to canvases properly"""
    try:
        import tkinter as tk
        from core.interpreter import TimeWarpInterpreter
        
        # Create a test canvas
        root = tk.Tk()
        root.withdraw()
        canvas = tk.Canvas(root, width=400, height=300)
        
        # Create interpreter and connect canvas
        interp = TimeWarpInterpreter()
        setattr(interp, 'ide_turtle_canvas', canvas)
        
        # Initialize turtle graphics with the connected canvas
        interp.init_turtle_graphics()
        
        # Test that the canvas is properly connected
        if interp.turtle_graphics and interp.turtle_graphics['canvas'] == canvas:
            print("✅ Interpreter-canvas connection works")
            root.destroy()
            return True
        else:
            print("❌ Interpreter-canvas connection failed")
            root.destroy()
            return False
            
    except Exception as e:
        print(f"❌ Interpreter-canvas connection test failed: {e}")
        return False

def main():
    """Run GUI canvas integration tests"""
    print("🖼️  TimeWarp GUI Canvas Integration Test")
    print("=" * 45)
    
    tests = [
        ("TimeWarp GUI Import", test_james_gui_import),
        ("TimeWarp Initialization", test_james_initialization),
        ("Canvas Connection", test_interpreter_canvas_connection),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
    
    print("\n" + "=" * 45)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All GUI canvas integration tests PASSED!")
        print("\n📋 GUI Canvas Status:")
        print("✅ TimeWarp IDE imports correctly")
        print("✅ Canvas components initialize properly")
        print("✅ Interpreter-canvas connection works")
        print("✅ Ready for full GUI operation")
    else:
        print("⚠️  Some GUI tests failed - check above for details")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)