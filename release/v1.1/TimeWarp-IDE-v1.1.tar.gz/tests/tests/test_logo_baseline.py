#!/usr/bin/env python3
"""
Test Logo interpreter without REPEAT to establish baseline functionality
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import TimeWarpInterpreter

def test_logo_baseline():
    """Test basic Logo features without REPEAT"""
    print("🔧 Testing Logo Baseline Features...")
    
    interpreter = TimeWarpInterpreter()
    
    # Test basic commands without REPEAT
    logo_program = """
CLEARSCREEN
HOME
SETCOLOR red
FORWARD 60
RIGHT 45
FORWARD 60
RIGHT 45
FORWARD 60
PENUP
SETXY 100 100
PENDOWN
SETCOLOR blue
FORWARD 50
RIGHT 90
FORWARD 50
HOME
"""
    
    print("Running Logo baseline program:")
    print("--- OUTPUT ---")
    
    try:
        interpreter.run_program(logo_program)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("--- END OUTPUT ---\n")

if __name__ == "__main__":
    test_logo_baseline()