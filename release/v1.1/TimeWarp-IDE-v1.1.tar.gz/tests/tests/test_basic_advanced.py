#!/usr/bin/env python3
"""
Advanced BASIC interpreter test - testing complex features
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import TimeWarpInterpreter

def test_basic_advanced():
    """Test advanced BASIC features"""
    print("🔧 Testing Advanced BASIC Features...")
    
    interpreter = TimeWarpInterpreter()
    
    # Test complex BASIC program with conditionals, loops, and subroutines
    basic_program = """
REM Advanced BASIC Test Program
PRINT "=== Advanced BASIC Test ==="

REM Test variables and expressions
LET PI = 3.14159
LET RADIUS = 5
LET AREA = PI * RADIUS * RADIUS
PRINT "Circle with radius"; RADIUS; "has area"; AREA

REM Test conditionals
IF RADIUS > 3 THEN PRINT "Large circle"
IF RADIUS <= 3 THEN PRINT "Small circle"

REM Test nested FOR loops
PRINT "Multiplication table:"
FOR I = 1 TO 3
    FOR J = 1 TO 3
        LET PRODUCT = I * J
        PRINT I; "x"; J; "="; PRODUCT
    NEXT J
NEXT I

REM Test GOSUB/RETURN
PRINT "Calling subroutine..."
GOSUB 1000
PRINT "Back from subroutine"
GOTO 2000

1000 REM Subroutine
PRINT "Inside subroutine"
RETURN

2000 REM Continue
PRINT "Program complete"
END
"""
    
    print("Running Advanced BASIC program:")
    print("--- OUTPUT ---")
    
    try:
        interpreter.run_program(basic_program)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("--- END OUTPUT ---\n")

if __name__ == "__main__":
    test_basic_advanced()