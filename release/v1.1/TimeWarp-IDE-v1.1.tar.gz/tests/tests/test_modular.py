#!/usr/bin/env python3
"""
Test script for the modular TimeWarp structure
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, '/path/to/timewarp')

try:
    # Test importing the core interpreter
    from core.interpreter import TimeWarpInterpreter
    print("✓ Successfully imported TimeWarpInterpreter")
    
    # Test importing language executors
    from core.languages import PilotExecutor, BasicExecutor, LogoExecutor
    print("✓ Successfully imported language executors")
    
    # Test importing utilities
    from core.utilities import Mixer, Tween, Timer, Particle, ArduinoController
    print("✓ Successfully imported utilities")
    
    # Test creating an interpreter instance
    interpreter = TimeWarpInterpreter()
    print("✓ Successfully created TimeWarpInterpreter instance")
    
    # Test basic functionality
    result = interpreter.execute_line("T:Hello from modular TimeWarp!")
    print(f"✓ Test command executed: {result}")
    
    print("\n🎉 All modular structure tests passed!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Error: {e}")
    sys.exit(1)