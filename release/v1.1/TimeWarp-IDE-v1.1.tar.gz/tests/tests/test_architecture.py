#!/usr/bin/env python3
"""
Test script for the new TimeWarp modular architecture
Tests the framework, tool manager, and advanced debugger plugin
"""

import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox

# Add TimeWarp directory to path
sys.path.insert(0, os.path.dirname(__file__))

# Test imports
try:
    from core.framework import TimeWarpFramework, ToolPlugin
    from tools.tool_manager import ToolManager, ToolManagerDialog
    print("✅ Core framework imports successful")
except ImportError as e:
    print(f"❌ Framework import error: {e}")
    sys.exit(1)

# Mock IDE instance for testing
class MockIDE:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🧪 TimeWarp Architecture Test")
        self.root.geometry("800x600")
        
        # Mock interpreter
        self.interpreter = None
        
        # Mock menu and toolbar methods
        self.menu_items = []
        self.toolbar_items = []
    
    def add_tool_menu_item(self, path, label, command, accelerator=None):
        """Mock menu item addition"""
        self.menu_items.append({
            'path': path,
            'label': label, 
            'command': command,
            'accelerator': accelerator
        })
        print(f"📋 Added menu item: {path} → {label}")
    
    def add_tool_toolbar_item(self, label, command, icon=None, tooltip=None):
        """Mock toolbar item addition"""
        self.toolbar_items.append({
            'label': label,
            'command': command,
            'icon': icon,
            'tooltip': tooltip
        })
        print(f"🔧 Added toolbar item: {label}")
    
    def remove_tool_menu_item(self, path, label):
        """Mock menu item removal"""
        print(f"🗑️ Removed menu item: {path} → {label}")
    
    def remove_tool_toolbar_item(self, label):
        """Mock toolbar item removal"""
        print(f"🗑️ Removed toolbar item: {label}")


def test_framework():
    """Test the core framework"""
    print("\n🔬 Testing Core Framework...")
    
    mock_ide = MockIDE()
    framework = TimeWarpFramework(mock_ide)
    
    # Test framework initialization
    assert framework.ide is mock_ide
    assert framework.event_manager is not None
    assert framework.registry is not None
    
    print("✅ Framework initialization successful")
    
    # Test event system
    test_event_fired = False
    
    def test_callback():
        nonlocal test_event_fired
        test_event_fired = True
    
    framework.event_manager.subscribe('test_event', test_callback)
    framework.event_manager.emit('test_event')
    
    assert test_event_fired, "Event system not working"
    print("✅ Event system working")
    
    # Test component registry
    framework.registry.register('test_component', 'test_value')
    assert framework.registry.get('test_component') == 'test_value'
    print("✅ Component registry working")
    
    return framework, mock_ide


def test_tool_manager(framework, mock_ide):
    """Test the tool manager"""
    print("\n🔧 Testing Tool Manager...")
    
    tool_manager = ToolManager(mock_ide, framework)
    
    # Test tool scanning
    available_tools = tool_manager.scan_tools()
    print(f"📦 Found {len(available_tools)} available tools: {available_tools}")
    
    # Test loading advanced debugger if available
    if 'advanced_debugger' in available_tools:
        print("🐛 Testing Advanced Debugger loading...")
        
        success = tool_manager.load_tool('advanced_debugger')
        if success:
            print("✅ Advanced Debugger loaded successfully")
            
            # Test activation
            activation_success = tool_manager.activate_tool('advanced_debugger')
            if activation_success:
                print("✅ Advanced Debugger activated successfully")
                
                # Test showing tool
                show_success = tool_manager.show_tool('advanced_debugger')
                if show_success:
                    print("✅ Advanced Debugger UI shown successfully")
                else:
                    print("⚠️ Could not show Advanced Debugger UI")
            else:
                print("❌ Failed to activate Advanced Debugger")
        else:
            print("❌ Failed to load Advanced Debugger")
    else:
        print("⚠️ Advanced Debugger not found in available tools")
    
    return tool_manager


def test_tool_manager_dialog(tool_manager, mock_ide):
    """Test the tool manager dialog"""
    print("\n🖥️ Testing Tool Manager Dialog...")
    
    try:
        dialog = ToolManagerDialog(mock_ide, tool_manager)
        
        # Show dialog for testing
        dialog.show()
        print("✅ Tool Manager Dialog created successfully")
        
        # Test refresh
        dialog.refresh_tools()
        print("✅ Tool refresh working")
        
        return dialog
    except Exception as e:
        print(f"❌ Tool Manager Dialog error: {e}")
        return None


def run_interactive_test(framework, mock_ide, tool_manager, dialog):
    """Run interactive test with GUI"""
    print("\n🖥️ Starting Interactive Test...")
    
    # Create test UI
    main_frame = ttk.Frame(mock_ide.root)
    main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
    
    # Title
    title_label = ttk.Label(main_frame, text="🧪 TimeWarp Architecture Test", 
                           font=("Arial", 16, "bold"))
    title_label.pack(pady=10)
    
    # Status frame
    status_frame = ttk.LabelFrame(main_frame, text="Test Status")
    status_frame.pack(fill=tk.X, pady=10)
    
    # Framework status
    framework_status = ttk.Label(status_frame, text=f"✅ Framework: {len(framework.list_tools())} tools registered")
    framework_status.pack(anchor='w', padx=10, pady=5)
    
    # Tool manager status
    loaded_tools = len(tool_manager.list_loaded_tools())
    active_tools = len(tool_manager.list_active_tools())
    tm_status = ttk.Label(status_frame, text=f"✅ Tool Manager: {loaded_tools} loaded, {active_tools} active")
    tm_status.pack(anchor='w', padx=10, pady=5)
    
    # Control buttons
    button_frame = ttk.Frame(main_frame)
    button_frame.pack(fill=tk.X, pady=20)
    
    def show_tool_manager():
        if dialog:
            dialog.show()
        else:
            messagebox.showerror("Error", "Tool Manager Dialog not available")
    
    def auto_load_tools():
        tool_manager.auto_load_tools()
        # Update status
        loaded_tools = len(tool_manager.list_loaded_tools())
        active_tools = len(tool_manager.list_active_tools())
        tm_status.config(text=f"✅ Tool Manager: {loaded_tools} loaded, {active_tools} active")
        messagebox.showinfo("Success", f"Auto-loaded {loaded_tools} tools")
    
    def show_framework_info():
        info = f"""Framework Information:
        
Tools: {len(framework.list_tools())}
Active Tools: {len(framework.list_active_tools())}
Categories: {len(framework.list_categories())}
Events: {len(framework.event_manager._listeners)}
Components: {len(framework.registry.list_components())}

Loaded Tools:
{chr(10).join(f"• {tool}" for tool in framework.list_tools())}

Categories:
{chr(10).join(f"• {cat}" for cat in framework.list_categories())}"""
        
        info_dialog = tk.Toplevel(mock_ide.root)
        info_dialog.title("Framework Information")
        info_dialog.geometry("400x500")
        
        info_text = tk.Text(info_dialog, font=('Consolas', 10), wrap=tk.WORD)
        info_scroll = ttk.Scrollbar(info_dialog, orient=tk.VERTICAL, command=info_text.yview)
        info_text.config(yscrollcommand=info_scroll.set)
        
        info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        info_scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=10)
        
        info_text.insert("1.0", info)
        info_text.config(state=tk.DISABLED)
    
    ttk.Button(button_frame, text="🛠️ Show Tool Manager", 
              command=show_tool_manager).pack(side=tk.LEFT, padx=5)
    ttk.Button(button_frame, text="⚡ Auto-Load Tools", 
              command=auto_load_tools).pack(side=tk.LEFT, padx=5)
    ttk.Button(button_frame, text="ℹ️ Framework Info", 
              command=show_framework_info).pack(side=tk.LEFT, padx=5)
    ttk.Button(button_frame, text="❌ Exit", 
              command=mock_ide.root.quit).pack(side=tk.LEFT, padx=5)
    
    # Instructions
    instructions = ttk.Label(main_frame, 
                           text="Use the buttons above to test the new TimeWarp architecture.\n"
                                "The Tool Manager shows all available tools and their status.\n"
                                "Auto-Load will load all available tools automatically.",
                           font=("Arial", 10),
                           justify=tk.CENTER)
    instructions.pack(pady=20)
    
    print("✅ Interactive test UI ready")
    mock_ide.root.mainloop()


def main():
    """Main test function"""
    print("🚀 Starting TimeWarp Architecture Test")
    print("=" * 50)
    
    try:
        # Test framework
        framework, mock_ide = test_framework()
        
        # Test tool manager  
        tool_manager = test_tool_manager(framework, mock_ide)
        
        # Test tool manager dialog
        dialog = test_tool_manager_dialog(tool_manager, mock_ide)
        
        print("\n" + "=" * 50)
        print("✅ All tests completed successfully!")
        print("\n📊 Test Summary:")
        print(f"• Framework: ✅ Working")
        print(f"• Tool Manager: ✅ Working") 
        print(f"• Available Tools: {len(tool_manager.list_available_tools())}")
        print(f"• Loaded Tools: {len(tool_manager.list_loaded_tools())}")
        print(f"• Active Tools: {len(tool_manager.list_active_tools())}")
        
        # Run interactive test
        if len(sys.argv) > 1 and sys.argv[1] == '--interactive':
            run_interactive_test(framework, mock_ide, tool_manager, dialog)
        else:
            print("\n💡 Run with --interactive flag to test the UI")
            
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)