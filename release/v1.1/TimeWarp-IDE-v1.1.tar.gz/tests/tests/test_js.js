console.log("Hello from JavaScript in TimeWarp IDE!");
const name = "TimeWarp";
console.log(`Welcome to ${name} IDE with JavaScript support`);