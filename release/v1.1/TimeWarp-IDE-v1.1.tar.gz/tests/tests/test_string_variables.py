#!/usr/bin/env python3
"""
Test string variable storage and retrieval
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.interpreter import TimeWarpInterpreter

def test_string_variables():
    """Test string variable handling"""
    print("🔧 Testing String Variables...")
    
    interpreter = TimeWarpInterpreter()
    
    # Test basic string assignment
    basic_program = """
10 LET A$ = "Hello"
20 PRINT "Variable A$ contains:", A$
30 PRINT "Direct variable:", A$
40 END
"""
    
    print("Testing string variable assignment and retrieval:")
    print("Program:")
    for line in basic_program.strip().split('\n'):
        if line.strip():
            print(f"  {line}")
    print("\nOutput:")
    
    try:
        interpreter.run_program(basic_program)
        
        # Check what's actually stored in variables
        print(f"\nVariable contents: {interpreter.variables}")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_string_variables()