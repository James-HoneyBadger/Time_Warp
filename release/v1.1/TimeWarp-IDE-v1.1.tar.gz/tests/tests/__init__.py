"""
TimeWarp IDE Test Suite
Comprehensive testing framework for all TimeWarp IDE components
"""

__version__ = "1.0.0"
__author__ = "TimeWarp IDE Team"
