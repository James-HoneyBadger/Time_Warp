#!/usr/bin/env python3
"""
Standalone Learning Assistant Plugin Demo
Demonstrates the plugin functionality without full TimeWarp integration
"""

import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox
import json
import datetime
from typing import Dict, List, Optional, Any

# Add the project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

# Import just the core classes from the plugin
from tools.plugins.learning_assistant.plugin import (
    CodeAnalyzer, TutorialManager, LearningPath
)


class StandaloneLearningAssistant:
    """Standalone version of the Learning Assistant for demonstration"""
    
    def __init__(self):
        self.name = "Learning Assistant (Standalone)"
        self.version = "1.0.0"
        
        # Core components
        self.code_analyzer = CodeAnalyzer()
        self.tutorial_manager = TutorialManager()
        self.learning_paths: Dict[str, LearningPath] = {}
        self.user_progress = {}
        
        # UI components
        self.root = None
        self.notebook = None
        
        self.create_default_learning_paths()
    
    def create_default_learning_paths(self):
        """Create default learning paths"""
        self.learning_paths = {
            'beginner_programmer': LearningPath(
                "Complete Beginner",
                "Start from scratch and learn programming fundamentals",
                [
                    {'type': 'tutorial', 'id': 'pilot_basics', 'title': 'PILOT Basics'},
                    {'type': 'practice', 'id': 'pilot_exercises', 'title': 'PILOT Practice'},
                    {'type': 'tutorial', 'id': 'basic_fundamentals', 'title': 'BASIC Fundamentals'},
                    {'type': 'project', 'id': 'simple_calculator', 'title': 'Build a Calculator'}
                ]
            ),
            'graphics_explorer': LearningPath(
                "Graphics and Art",
                "Learn to create graphics and visual art with programming",
                [
                    {'type': 'tutorial', 'id': 'logo_graphics', 'title': 'Logo Turtle Graphics'},
                    {'type': 'project', 'id': 'geometric_art', 'title': 'Geometric Art Project'},
                    {'type': 'tutorial', 'id': 'advanced_graphics', 'title': 'Advanced Graphics'},
                    {'type': 'project', 'id': 'animation', 'title': 'Create Animations'}
                ]
            )
        }
    
    def run_demo(self):
        """Run the standalone demo"""
        self.root = tk.Tk()
        self.root.title("🎓 Learning Assistant - Standalone Demo")
        self.root.geometry("1200x800")
        
        # Create main interface
        self.create_demo_interface()
        
        # Start the main loop
        self.root.mainloop()
    
    def create_demo_interface(self):
        """Create the demo interface"""
        # Create notebook with tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create tabs
        self.create_overview_tab()
        self.create_code_analysis_demo()
        self.create_tutorial_demo()
        self.create_learning_paths_demo()
    
    def create_overview_tab(self):
        """Create overview tab"""
        overview_frame = ttk.Frame(self.notebook)
        self.notebook.add(overview_frame, text="📋 Overview")
        
        # Title
        title_label = ttk.Label(overview_frame, 
                               text="🎓 Learning Assistant Plugin", 
                               font=('Arial', 16, 'bold'))
        title_label.pack(pady=20)
        
        # Description
        desc_text = """
The Learning Assistant Plugin provides comprehensive educational features for TimeWarp IDE:

🔍 Code Analysis
• Analyzes code quality for PILOT, BASIC, Logo, and Python
• Provides educational feedback and suggestions
• Scores code on readability, structure, and best practices

📚 Interactive Tutorials
• Step-by-step tutorials for each supported language
• Hands-on coding exercises with hints and explanations
• Progress tracking and completion certificates

🛤️ Learning Paths
• Structured learning journeys for different goals
• Beginner-friendly progression through programming concepts
• Adaptive content based on user progress

🏆 Achievements & Gamification
• Earn badges for completing tutorials and improving code quality
• Track learning streaks and milestones
• Visual progress indicators and statistics

🎯 Educational Focus
• Designed specifically for learning programming
• Age-appropriate content and explanations
• Encourages best practices from the beginning
        """
        
        desc_label = ttk.Label(overview_frame, text=desc_text.strip(), 
                              justify=tk.LEFT, wraplength=600)
        desc_label.pack(padx=20, pady=20)
        
        # Demo controls
        demo_frame = ttk.LabelFrame(overview_frame, text="Demo Controls")
        demo_frame.pack(fill=tk.X, padx=20, pady=10)
        
        ttk.Button(demo_frame, text="🔍 Try Code Analysis", 
                  command=lambda: self.notebook.select(1)).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(demo_frame, text="📚 View Tutorials", 
                  command=lambda: self.notebook.select(2)).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(demo_frame, text="🛤️ Explore Learning Paths", 
                  command=lambda: self.notebook.select(3)).pack(side=tk.LEFT, padx=5, pady=5)
    
    def create_code_analysis_demo(self):
        """Create code analysis demonstration"""
        analysis_frame = ttk.Frame(self.notebook)
        self.notebook.add(analysis_frame, text="🔍 Code Analysis")
        
        # Instructions
        instructions = ttk.Label(analysis_frame, 
                                text="Enter code below and click 'Analyze' to see educational feedback:",
                                font=('Arial', 12))
        instructions.pack(pady=10)
        
        # Language selection
        lang_frame = ttk.Frame(analysis_frame)
        lang_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(lang_frame, text="Language:").pack(side=tk.LEFT)
        self.analysis_language_var = tk.StringVar(value="pilot")
        lang_combo = ttk.Combobox(lang_frame, textvariable=self.analysis_language_var,
                                 values=["pilot", "basic", "logo", "python"], state="readonly")
        lang_combo.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(lang_frame, text="🔍 Analyze Code", 
                  command=self.demo_analyze_code).pack(side=tk.LEFT, padx=10)
        ttk.Button(lang_frame, text="📝 Load Example", 
                  command=self.load_example_code).pack(side=tk.LEFT, padx=5)
        
        # Code input area
        code_frame = ttk.LabelFrame(analysis_frame, text="Code to Analyze")
        code_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.analysis_code_text = tk.Text(code_frame, height=10, font=('Courier', 10))
        self.analysis_code_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Results area
        results_frame = ttk.LabelFrame(analysis_frame, text="Analysis Results")
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Score display
        score_frame = ttk.Frame(results_frame)
        score_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.score_label = ttk.Label(score_frame, text="Quality Score: --", font=('Arial', 12, 'bold'))
        self.score_label.pack(side=tk.LEFT)
        
        self.quality_label = ttk.Label(score_frame, text="", font=('Arial', 12))
        self.quality_label.pack(side=tk.LEFT, padx=20)
        
        # Results text
        self.analysis_results_text = tk.Text(results_frame, height=8, wrap=tk.WORD, state=tk.DISABLED)
        self.analysis_results_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Load initial example
        self.load_example_code()
    
    def create_tutorial_demo(self):
        """Create tutorial demonstration"""
        tutorial_frame = ttk.Frame(self.notebook)
        self.notebook.add(tutorial_frame, text="📚 Tutorials")
        
        # Instructions
        instructions = ttk.Label(tutorial_frame, 
                                text="Interactive tutorials guide you through programming concepts:",
                                font=('Arial', 12))
        instructions.pack(pady=10)
        
        # Tutorial list
        list_frame = ttk.LabelFrame(tutorial_frame, text="Available Tutorials")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Create listbox with tutorials
        self.tutorial_listbox = tk.Listbox(list_frame, height=8)
        self.tutorial_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.tutorial_listbox.bind('<<ListboxSelect>>', self.on_demo_tutorial_select)
        
        # Populate tutorials
        for tutorial_id, tutorial in self.tutorial_manager.tutorials.items():
            display_name = f"[{tutorial['language'].upper()}] {tutorial['title']}"
            self.tutorial_listbox.insert(tk.END, display_name)
        
        # Tutorial content display
        content_frame = ttk.LabelFrame(tutorial_frame, text="Tutorial Content")
        content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.tutorial_content_text = tk.Text(content_frame, height=8, wrap=tk.WORD, state=tk.DISABLED)
        self.tutorial_content_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Select first tutorial
        if self.tutorial_listbox.size() > 0:
            self.tutorial_listbox.selection_set(0)
            self.on_demo_tutorial_select(None)
    
    def create_learning_paths_demo(self):
        """Create learning paths demonstration"""
        paths_frame = ttk.Frame(self.notebook)
        self.notebook.add(paths_frame, text="🛤️ Learning Paths")
        
        # Instructions
        instructions = ttk.Label(paths_frame, 
                                text="Structured learning journeys for different programming goals:",
                                font=('Arial', 12))
        instructions.pack(pady=10)
        
        # Create path cards
        for path_id, path in self.learning_paths.items():
            self.create_path_card(paths_frame, path)
    
    def create_path_card(self, parent, path: LearningPath):
        """Create a card display for a learning path"""
        card_frame = ttk.LabelFrame(parent, text=f"🛤️ {path.name}")
        card_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Description
        desc_label = ttk.Label(card_frame, text=path.description, wraplength=500)
        desc_label.pack(anchor=tk.W, padx=10, pady=5)
        
        # Lessons list
        lessons_text = "Lessons:\n"
        for i, lesson in enumerate(path.lessons, 1):
            status = "✅" if i-1 in path.completed_lessons else "⭕"
            lessons_text += f"  {status} {i}. {lesson['title']}\n"
        
        lessons_label = ttk.Label(card_frame, text=lessons_text, font=('Courier', 9))
        lessons_label.pack(anchor=tk.W, padx=10, pady=5)
        
        # Progress
        progress_text = f"Progress: {len(path.completed_lessons)}/{len(path.lessons)} completed"
        progress_label = ttk.Label(card_frame, text=progress_text, font=('Arial', 10, 'bold'))
        progress_label.pack(anchor=tk.W, padx=10, pady=5)
    
    def demo_analyze_code(self):
        """Demonstrate code analysis"""
        code = self.analysis_code_text.get(1.0, tk.END).strip()
        language = self.analysis_language_var.get()
        
        if not code:
            messagebox.showwarning("No Code", "Please enter some code to analyze.")
            return
        
        # Perform analysis
        results = self.code_analyzer.analyze_code(code, language)
        
        # Update UI
        self.score_label.config(text=f"Quality Score: {results['score']}/100")
        self.quality_label.config(text=f"Quality: {results['quality'].title()}")
        
        # Color code the quality
        quality_colors = {
            'excellent': 'green',
            'good': 'blue', 
            'fair': 'orange',
            'needs improvement': 'red'
        }
        self.quality_label.config(foreground=quality_colors.get(results['quality'], 'black'))
        
        # Display suggestions
        self.analysis_results_text.config(state=tk.NORMAL)
        self.analysis_results_text.delete(1.0, tk.END)
        
        if results['suggestions']:
            self.analysis_results_text.insert(tk.END, "📋 Educational Feedback:\n\n")
            
            for i, suggestion in enumerate(results['suggestions'], 1):
                self.analysis_results_text.insert(tk.END, f"{i}. {suggestion['message']}\n")
                self.analysis_results_text.insert(tk.END, f"   💡 {suggestion['suggestion']}\n\n")
        else:
            self.analysis_results_text.insert(tk.END, "🎉 Excellent! Your code follows good practices.")
        
        self.analysis_results_text.config(state=tk.DISABLED)
    
    def load_example_code(self):
        """Load example code based on selected language"""
        language = self.analysis_language_var.get()
        
        examples = {
            'pilot': '''R: This is a PILOT program to greet users
T: Welcome to PILOT programming!
T: What is your name?
A: #NAME
T: Hello, #NAME! Nice to meet you.
*MENU
T: Choose an option:
T: 1. See a joke
T: 2. Exit
A: #CHOICE
M: #CHOICE, 1, *JOKE
M: #CHOICE, 2, *END
J: *MENU
*JOKE
T: Why do programmers prefer dark mode?
T: Because light attracts bugs! 😄
J: *MENU
*END
T: Thanks for using PILOT!
E:''',
            
            'basic': '''10 REM Simple BASIC Calculator
20 PRINT "Welcome to BASIC Calculator"
30 PRINT "Enter two numbers:"
40 INPUT "First number: "; A
50 INPUT "Second number: "; B
60 PRINT "Choose operation:"
70 PRINT "1. Add  2. Subtract  3. Multiply  4. Divide"
80 INPUT "Choice (1-4): "; C
90 IF C = 1 THEN RESULT = A + B
100 IF C = 2 THEN RESULT = A - B
110 IF C = 3 THEN RESULT = A * B
120 IF C = 4 THEN RESULT = A / B
130 PRINT "Result: "; RESULT
140 END''',
            
            'logo': '''TO SQUARE :SIZE
  REPEAT 4 [
    FORWARD :SIZE
    RIGHT 90
  ]
END

TO SPIRAL :SIZE
  REPEAT 36 [
    FORWARD :SIZE
    RIGHT 10
    SQUARE :SIZE
  ]
END

; Draw a colorful spiral of squares
CLEARSCREEN
PENDOWN
SPIRAL 20''',
            
            'python': '''def fibonacci(n):
    """Generate Fibonacci sequence up to n terms"""
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    
    fib_list = [0, 1]
    for i in range(2, n):
        fib_list.append(fib_list[i-1] + fib_list[i-2])
    
    return fib_list

if __name__ == "__main__":
    num_terms = int(input("How many Fibonacci numbers? "))
    sequence = fibonacci(num_terms)
    print(f"Fibonacci sequence: {sequence}")'''
        }
        
        self.analysis_code_text.delete(1.0, tk.END)
        self.analysis_code_text.insert(1.0, examples[language])
    
    def on_demo_tutorial_select(self, event):
        """Handle tutorial selection in demo"""
        selection = self.tutorial_listbox.curselection()
        if not selection:
            return
        
        tutorial_ids = list(self.tutorial_manager.tutorials.keys())
        if selection[0] < len(tutorial_ids):
            tutorial_id = tutorial_ids[selection[0]]
            tutorial = self.tutorial_manager.tutorials[tutorial_id]
            
            # Display tutorial information
            content = f"{tutorial['title']}\n"
            content += "=" * len(tutorial['title']) + "\n\n"
            content += f"Language: {tutorial['language'].upper()}\n"
            content += f"Difficulty: {tutorial['difficulty'].title()}\n"
            content += f"Steps: {len(tutorial['steps'])}\n\n"
            
            # Show first step as preview
            if tutorial['steps']:
                first_step = tutorial['steps'][0]
                content += f"Preview - {first_step['title']}:\n"
                content += f"{first_step['content']}\n\n"
                content += f"Example Code:\n{first_step['code']}\n\n"
                content += f"Task: {first_step['task']}"
            
            self.tutorial_content_text.config(state=tk.NORMAL)
            self.tutorial_content_text.delete(1.0, tk.END)
            self.tutorial_content_text.insert(1.0, content)
            self.tutorial_content_text.config(state=tk.DISABLED)


def main():
    """Run the standalone demo"""
    print("🎓 Learning Assistant Plugin - Standalone Demo")
    print("=" * 50)
    
    try:
        # Create and run the demo
        demo = StandaloneLearningAssistant()
        demo.run_demo()
        
    except KeyboardInterrupt:
        print("\n👋 Demo interrupted by user")
    except Exception as e:
        print(f"❌ Demo error: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()