#!/usr/bin/env python3
"""Test pygame graphics window with event handling"""

from core.interpreter import TimeWarpInterpreter
import time

def test_pygame_graphics():
    interp = TimeWarpInterpreter()
    
    print("Initializing pygame graphics...")
    
    # Initialize graphics
    interp.execute_line("GAMESCREEN 640, 480")
    print("✓ GAMESCREEN executed")
    
    # Set dark blue background
    interp.execute_line('GAMEBG 0, 0, 100')
    print("✓ GAMEBG executed")
    
    # Draw various shapes with different colors
    interp.execute_line('GAMECOLOR 255, 0, 0')  # Red
    interp.execute_line('GAMERECT 50, 50, 100, 80, 1')  # Filled rectangle
    print("✓ Red rectangle drawn")
    
    interp.execute_line('GAMECOLOR 0, 255, 0')  # Green  
    interp.execute_line('GAMECIRCLE 300, 200, 60')  # Circle
    print("✓ Green circle drawn")
    
    interp.execute_line('GAMECOLOR 255, 255, 0')  # Yellow
    interp.execute_line('GAMETEXT 200, 350, "PYGAME GRAPHICS TEST"')
    print("✓ Yellow text drawn")
    
    # Draw some stars
    interp.execute_line('GAMECOLOR 255, 255, 255')  # White
    for i in range(20):
        interp.execute_line(f'GAMEPOINT {100 + i*10}, {100 + (i%3)*5}')
    print("✓ Star pattern drawn")
    
    # Update display
    interp.execute_line('GAMEUPDATE')
    print("✓ Display updated")
    
    print("\n🎮 Pygame window should be visible with graphics!")
    print("If you can see a window with colored shapes, pygame graphics is working!")
    
    # Keep window open for a while
    print("Keeping window open for 15 seconds...")
    for i in range(15):
        interp.execute_line('GAMEDELAY 1000')  # 1 second delay
        print(f"  {15-i} seconds remaining...")
    
    print("Test complete!")

if __name__ == "__main__":
    test_pygame_graphics()