#!/bin/bash
# Simple TimeWarp IDE Launcher
echo "🚀 Starting TimeWarp IDE 1.1..."
python3 TimeWarp.py